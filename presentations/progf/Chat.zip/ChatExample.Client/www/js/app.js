var t_UrlPart___, t_UrlPart_, t_UInt64_, t_UInt32_, t_Tuple_2___, t_Tuple_2_String__Message_, t_String_, t_PrimitiveType_, t_Message_, t_Int64_, t_Int32_, t_FSharpOption_1_Tuple_2___, t_Double_, t_Decimal_, t_Boolean_, list_1_Tuple_2_String__String__NilTuple_2_String__String_, list_1_Tuple_2_String__String__ConsTuple_2_String__String_, list_1_String__NilString, list_1_String__ConsString, list_1_Object__NilObject_, list_1_Object__ConsObject_, Web__sendRequest$Unit_Unit_, WebResponse__get_ContentLength$, WebResponse___ctor$, WebResponse__GetResponseStream$, WebRequest__set_Method$, WebRequest__get_Method$, WebRequest__get_Headers$, WebRequest___ctor$, WebRequest__GetRequestStream$, WebRequest__Create$, WebRequest__AsyncGetResponse$, WebHeaderCollection__get_Values$, WebHeaderCollection__get_Keys$, WebHeaderCollection___ctor$, WebHeaderCollection__Add$, Utilities__memoizeRecLazy$Type_1_FSharpFunc_2_JsonReader__Object_Type_1_FSharpFunc_2_JsonReader__Object_, Utilities__memoizeRec$Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_, UrlPart__VariablePart, UrlPart__FixedPart, UnionCaseInfo__get_Name$, UnionCaseInfo___ctor$, UnionCaseInfo__GetFields$, UnionCaseInfo__Construct$, UnfoldEnumerator_2_Int32__String___ctor$Int32_String, UTF8Encoding___ctor$, UTF8Encoding__GetString$, UTF8Encoding__GetBytes$, Type__get_Name$, Type__get_Kind$, Type__get_IsArray$, Type__get_FullName$, Type___ctor$, Type__GetElementType$, TypeKind__UnionType, TypeKind__TupleType, TypeKind__RecordType, TypeKind__ClassType, TypeKind__ArrayType, TupleString_String, TupleString_Message_, TupleString_Int32, TupleSetTree_1_Char__SetTree_1_Char_, TupleMapTree_2_String__Int32__MapTree_2_String__Int32_, TupleMapTree_2_Int32__Object__MapTree_2_Int32__Object_, TupleMapTree_2_IComparable__Object__MapTree_2_IComparable__Object_, TupleFSharpFunc_2_WebResponse__Unit__FSharpFunc_2_String__Unit__FSharpFunc_2_String__Unit_, TupleFSharpFunc_2_Object____Object__FSharpMap_2_String__Int32_1_Lazy_1___, String_1_Substring$, String_1_Length$, String_1_Join$, String_1_CharAt$, Stream__get_Contents$, Stream___ctor$, Stream__AsyncWrite$, Stream__AsyncRead$, Set__OfArray$Char_Char, Set__Contains$Char_Char, Set_1_Char__get_Tree$Char, Set_1_Char__get_Comparer$Char, Set_1_Char___ctor$Char, Set_1_Char__FromArray$Char, Set_1_Char__Contains$Char, SetTree_1_Char__SetOneChar, SetTree_1_Char__SetNodeChar, SetTree_1_Char__SetEmptyChar, SetTreeModule__tolerance, SetTreeModule__rebalance$Char_Char, SetTreeModule__ofArray$Char_Char, SetTreeModule__mk$Char_Char, SetTreeModule__mem$Char_Char, SetTreeModule__height$Char_Char, SetTreeModule__get_tolerance$, SetTreeModule__add$Char_Char, SetTreeModule__SetOne$Char_Char, SetTreeModule__SetNode$Char_Char, Serialization__get_deserializers$, Serialization__getDeserializer$, Serialization__deserializers, Serialization__deserialize$, SerializationExtensions__precomputeTypeFromJson$, SerializationExtensions__precomputeDeserializerAux$, SerializationExtensions__precomputeDeserializer$, SerializationExtensions__isType$UInt64_UInt64, SerializationExtensions__isType$UInt32_UInt32, SerializationExtensions__isType$String_String, SerializationExtensions__isType$Int64_Int64, SerializationExtensions__isType$Int32_Int32, SerializationExtensions__isType$Double_Double, SerializationExtensions__isType$Decimal_Decimal, SerializationExtensions__isType$Boolean_Boolean, SerializationExtensions__get_accessFlags$, SerializationExtensions__accessFlags, SerializationExtensions___UnionType___$, SerializationExtensions___UInt64Type___$, SerializationExtensions___UInt32Type___$, SerializationExtensions___TupleType___$, SerializationExtensions___StringType___$, SerializationExtensions___RecordType___$, SerializationExtensions___Int64Type___$, SerializationExtensions___Int32Type___$, SerializationExtensions___FloatType___$, SerializationExtensions___DecimalType___$, SerializationExtensions___BoolType___$, SerializationExtensions___ArrayType___$, Seq__Unfold$Int32__String_Int32_String, Seq__ToArray$String_String, Seq__OfArray$String_String, Seq__IterateIndexed$String_String, Seq__FromFactory$String_String, Seq__FoldIndexedAux$Unit__String_Unit__String, Seq__FoldIndexed$String__Unit_String_Unit_, Seq__Enumerator$String_String, Replacements__tryParseBool$, Replacements__parseInt$, Replacements__parseFloat$, Replacements__parseBool$, Replacements_1_utf8Encoding$, PropertyInfo__get_PropertyType$, PropertyInfo___ctor$, Program__trackMessages$Unit_Unit_, Program__sendMessage$, Program__op_Dynamic$JQuery_JQuery_, Program__main$, Program__jq$, Program__get_ctx$, Program__ctx, PrimitiveType__UIntType, PrimitiveType__StringType, PrimitiveType__IntType, PrimitiveType__HexType, PrimitiveType__FloatType, PrimitiveType__DecimalType, PrimitiveType__CharType, PrimitiveType__BoolType, Option__IsSome$Int32_Int32, Option__GetValue$UnionCaseInfo___UnionCaseInfo___, Option__GetValue$Type___Type___, Option__GetValue$Type_1Type_1, Option__GetValue$Tuple_2___Tuple_2___, Option__GetValue$Tuple_2_String__Int32_Tuple_2_String__Int32_, Option__GetValue$String_String, Option__GetValue$PropertyInfo___PropertyInfo___, Option__GetValue$Object_Object_, Option__GetValue$Int32_Int32, Option__GetValue$FSharpRef_1_Boolean_FSharpRef_1_Boolean_, Option__GetValue$FSharpFunc_2_String__Object_FSharpFunc_2_String__Object_, Option__GetValue$FSharpFunc_2_Object__String_FSharpFunc_2_Object__String_, Option__GetValue$Char_Char, Option__GetValue$CancellationToken_CancellationToken_, Option__GetValue$Boolean_Boolean, Message___ctor$, Map__OfArray$String__Int32_String_Int32, Map__Iterate$String__String_String_String, Map__Empty$String__String_String_String, Map__Empty$String__FSharpFunc_2_String__Object_String_FSharpFunc_2_String__Object_, Map__Empty$Int32__Object_Int32_Object_, MapTree_2_String__String__MapEmptyString_String, MapTree_2_String__Int32__MapOneString_Int32, MapTree_2_String__Int32__MapNodeString_Int32, MapTree_2_String__Int32__MapEmptyString_Int32, MapTree_2_String__FSharpFunc_2_String__Object__MapEmptyString_FSharpFunc_2_String__Object_, MapTree_2_Int32__Object__MapOneInt32_Object_, MapTree_2_Int32__Object__MapNodeInt32_Object_, MapTree_2_Int32__Object__MapEmptyInt32_Object_, MapTree_2_IComparable__Object__MapOneIComparable__Object_, MapTree_2_IComparable__Object__MapNodeIComparable__Object_, MapTree_2_IComparable__Object__MapEmptyIComparable__Object_, MapTreeModule__tryFind$Int32__Object_Int32_Object_, MapTreeModule__tryFind$IComparable__Object_IComparable__Object_, MapTreeModule__rebalance$String__Int32_String_Int32, MapTreeModule__rebalance$Int32__Object_Int32_Object_, MapTreeModule__rebalance$IComparable__Object_IComparable__Object_, MapTreeModule__ofArray$String__Int32_String_Int32, MapTreeModule__mk$String__Int32_String_Int32, MapTreeModule__mk$Int32__Object_Int32_Object_, MapTreeModule__mk$IComparable__Object_IComparable__Object_, MapTreeModule__iter$String__String_String_String, MapTreeModule__height$String__Int32_String_Int32, MapTreeModule__height$Int32__Object_Int32_Object_, MapTreeModule__height$IComparable__Object_IComparable__Object_, MapTreeModule__find$IComparable__Object_IComparable__Object_, MapTreeModule__empty$String__Int32_String_Int32, MapTreeModule__add$String__Int32_String_Int32, MapTreeModule__add$Int32__Object_Int32_Object_, MapTreeModule__add$IComparable__Object_IComparable__Object_, List__ToArray$String_String, List__ToArray$Object_Object_, List__Reverse$String_String, List__Map$Tuple_2_String__String__String_Tuple_2_String__String__String, List__Length$String_String, List__Length$Object_Object_, List__IterateIndexed$String_String, List__IterateIndexed$Object_Object_, List__FoldIndexedAux$list_1_String__Tuple_2_String__String_list_1_String__Tuple_2_String__String_, List__FoldIndexedAux$list_1_String__String_list_1_String__String, List__FoldIndexedAux$Unit__String_Unit__String, List__FoldIndexedAux$Unit__Object_Unit__Object_, List__FoldIndexedAux$Int32__String_Int32_String, List__FoldIndexedAux$Int32__Object_Int32_Object_, List__FoldIndexed$Tuple_2_String__String__list_1_String_Tuple_2_String__String__list_1_String_, List__FoldIndexed$String__list_1_String_String_list_1_String_, List__FoldIndexed$String__Unit_String_Unit_, List__FoldIndexed$String__Int32_String_Int32, List__FoldIndexed$Object__Unit_Object__Unit_, List__FoldIndexed$Object__Int32_Object__Int32, List__Fold$Tuple_2_String__String__list_1_String_Tuple_2_String__String__list_1_String_, List__Fold$String__list_1_String_String_list_1_String_, List__Fold$String__Int32_String_Int32, List__Fold$Object__Int32_Object__Int32, List__Empty$Tuple_2_String__String_Tuple_2_String__String_, List__Empty$Object_Object_, List__CreateCons$Tuple_2_String__String_Tuple_2_String__String_, List__CreateCons$Object_Object_, Lazy_1_Object__get_Value$Object_, Lazy_1_Object___ctor$Object_, Lazy_1_Object__Create$Object_, JsonReader__tryPeek$, JsonReader__tryConsume$, JsonReader__readUpToExcl$, JsonReader__consumeWhiteSpaceUpToIncl$, JsonReader__consumeWhiteSpace$, JsonReader__consume$, JsonReader___ctor$, JsonReader__ReadUpToSeparatorInclWhiteSpace$, JsonReader__ReadUpToQuoteMark$, JsonReader__Peek$, JsonReader__MovePastWhiteSpace$, JsonReader__MovePast$, JsonReaderHelpers__readValue$UInt32_UInt32, JsonReaderHelpers__readValue$Int64_Int64, JsonReaderHelpers__readValue$Int32_Int32, JsonReaderHelpers__readValue$Double_Double, JsonReaderHelpers__readValue$Decimal_Decimal, JsonReaderHelpers__readValue$Boolean_Boolean, JsonReaderHelpers__readJsonObject$Object_Object_, GenericComparer_1_String___ctor$String, GenericComparer_1_Int32___ctor$Int32, GenericComparer_1_Char___ctor$Char, FSharpValue__PreComputeUnionConstructor$, FSharpValue__PreComputeTupleConstructor$, FSharpValue__PreComputeRecordConstructor$, FSharpValue__MakeUnion$, FSharpValue__MakeTuple$, FSharpValue__MakeRecord$, FSharpType__IsUnion$, FSharpType__IsTuple$, FSharpType__IsRecord$, FSharpType__GetUnionCases$, FSharpType__GetTupleElements$, FSharpType__GetRecordFields$, FSharpString__Concat$, FSharpMap_2_String__String__get_Empty$String_String, FSharpMap_2_String__String___ctor$String_String, FSharpMap_2_String__String__Iterate$String_String, FSharpMap_2_String__Int32___ctor$String_Int32, FSharpMap_2_String__FSharpFunc_2_String__Object__get_Empty$String_FSharpFunc_2_String__Object_, FSharpMap_2_String__FSharpFunc_2_String__Object___ctor$String_FSharpFunc_2_String__Object_, FSharpMap_2_Int32__Object__get_Empty$Int32_Object_, FSharpMap_2_Int32__Object___ctor$Int32_Object_, FSharpMap_2_Int32__Object__TryFind$Int32_Object_, FSharpMap_2_Int32__Object__Add$Int32_Object_, FSharpMap_2_IComparable__Object__get_Item$IComparable__Object_, FSharpMap_2_IComparable__Object___ctor$IComparable__Object_, FSharpMap_2_IComparable__Object__TryFind$IComparable__Object_, FSharpMap_2_IComparable__Object__Add$IComparable__Object_, Dictionaries__setProperty$Unit_Unit_, Dictionaries__nextId, Dictionaries__hasProperty$Boolean_Boolean, Dictionaries__get_nextId$, Dictionaries__getUniqueObjectId$, Dictionaries__getProperty$Int32_Int32, CreateEnumerable_1_String___ctor$String, ConcurrentDictionary_2_Object__Object___ctor$Object__Object_, ConcurrentDictionary_2_Object__Object__GetOrAdd$Object__Object_, ConcurrentDictionary_2_Object__Object__Create$Object__Object_, CancellationToken___ctor$, CancellationToken__ThrowIfCancellationRequested$, Async__StartImmediate$, Async__FromContinuations$WebResponse_WebResponse_, Async_1_setTimeout$Unit_Unit_, Async_1_protectedCont$WebResponse_WebResponse_, Async_1_protectedCont$Unit_Unit_, Async_1_protectedCont$Object_Object_, Async_1_protectedCont$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___, Async_1_protectedCont$FSharpOption_1_String_FSharpOption_1_String_, Async_1_protectedCont$Byte___Byte___, Async_1_invokeCont$Unit_Unit_, Async_1_invokeCont$Object_Object_, Async_1_invokeCont$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___, Async_1_invokeCont$FSharpOption_1_String_FSharpOption_1_String_, Async_1_invokeCont$Byte___Byte___, Async_1_get_async$, Async_1_WebResponse__ContWebResponse_, Async_1_Unit__ContUnit_, Async_1_Object__ContObject_, Async_1_FSharpOption_1_Tuple_2____ContFSharpOption_1_Tuple_2___, Async_1_FSharpOption_1_String__ContFSharpOption_1_String_, Async_1_Byte____ContByte___, AsyncParams_1_WebResponse___ctor$WebResponse_1, AsyncParams_1_Unit___ctor$Unit_, AsyncParams_1_Object___ctor$Object_, AsyncParams_1_FSharpOption_1_Tuple_2_____ctor$FSharpOption_1_Tuple_2___, AsyncParams_1_FSharpOption_1_String___ctor$FSharpOption_1_String_, AsyncParams_1_Byte_____ctor$Byte___, AsyncParamsAux___ctor$, AsyncExtensions__Map$Object__FSharpOption_1_Tuple_2___Object__FSharpOption_1_Tuple_2___, AsyncBuilder___ctor$, AsyncBuilder__Zero$, AsyncBuilder__Using$WebResponse_1_FSharpOption_1_String_WebResponse_1_FSharpOption_1_String_, AsyncBuilder__Using$Stream_1_Unit_Stream_1_Unit_, AsyncBuilder__Using$Stream_1_FSharpOption_1_String_Stream_1_FSharpOption_1_String_, AsyncBuilder__ReturnFrom$Unit_Unit_, AsyncBuilder__Return$Unit_Unit_, AsyncBuilder__Return$Object_Object_, AsyncBuilder__Return$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___, AsyncBuilder__Return$FSharpOption_1_String_FSharpOption_1_String_, AsyncBuilder__Return$Byte___Byte___, AsyncBuilder__Delay$Unit_Unit_, AsyncBuilder__Delay$Object_Object_, AsyncBuilder__Delay$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___, AsyncBuilder__Delay$FSharpOption_1_String_FSharpOption_1_String_, AsyncBuilder__Delay$Byte___Byte___, AsyncBuilder__Combine$FSharpOption_1_String_FSharpOption_1_String_, AsyncBuilder__Bind$WebResponse_1_FSharpOption_1_String_WebResponse_1_FSharpOption_1_String_, AsyncBuilder__Bind$Unit__Unit_Unit__Unit_, AsyncBuilder__Bind$Unit__FSharpOption_1_String_Unit__FSharpOption_1_String_, AsyncBuilder__Bind$Object__FSharpOption_1_Tuple_2___Object__FSharpOption_1_Tuple_2___, AsyncBuilder__Bind$FSharpOption_1_Tuple_2____Unit_FSharpOption_1_Tuple_2____Unit_, AsyncBuilder__Bind$FSharpOption_1_String__Object_FSharpOption_1_String__Object_, AsyncBuilder__Bind$Byte____FSharpOption_1_String_Byte____FSharpOption_1_String_, Array__ZeroCreate$Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___, Array__ZeroCreate$Tuple_2_String__Message_Tuple_2_String__Message_, Array__ZeroCreate$Tuple_2_String__Int32_Tuple_2_String__Int32_, Array__ZeroCreate$String_String, Array__ZeroCreate$Object_Object_, Array__ZeroCreate$Lazy_1_FSharpFunc_2_JsonReader__Object_Lazy_1_FSharpFunc_2_JsonReader__Object_, Array__Reverse$Tuple_2_String__Message_Tuple_2_String__Message_, Array__MapIndexed$UrlPart__String_UrlPart__String, Array__MapIndexed$UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___, Array__MapIndexed$UnionCaseInfo_1_Tuple_2_String__Int32_UnionCaseInfo_1_Tuple_2_String__Int32_, Array__MapIndexed$Type_1_Tuple_2_String__Int32_Type_1_Tuple_2_String__Int32_, Array__MapIndexed$Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_, Array__MapIndexed$PropertyInfo_1_Tuple_2_String__Int32_PropertyInfo_1_Tuple_2_String__Int32_, Array__MapIndexed$PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_, Array__Map$UrlPart__String_UrlPart__String, Array__Map$UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___, Array__Map$Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_, Array__Map$PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_, Array__Length$UrlPart_UrlPart_, Array__Length$UnionCaseInfo_1UnionCaseInfo_1, Array__Length$Type_1Type_1, Array__Length$Tuple_2_String__Message_Tuple_2_String__Message_, Array__Length$PropertyInfo_1PropertyInfo_1, Array__Length$Char_Char, Array__Iterate$Tuple_2_String__Message_Tuple_2_String__Message_, Array__GetSubArray$Byte_Byte, Array__FoldIndexed$Unit__Tuple_2_String__Message_Unit__Tuple_2_String__Message_, Array__FoldIndexed$SetTree_1_Char__Char_SetTree_1_Char__Char, Array__Fold$Tuple_2_String__Message__Unit_Tuple_2_String__Message__Unit_, Array__Fold$Char__SetTree_1_Char_Char_SetTree_1_Char_, Array__CreateInstance$, Array__BoxedLength$, Array__Append$Byte_Byte, ApiRequest___ctor$, ApiRequest__SendAndDeserialize$, ApiRequest__Send$, ApiRequest__BuildUrl$, ApiRequest__AddParameter$, ApiDataContext___ctor$;
  ApiDataContext___ctor$ = (function (BaseUrl)
  {
    this.BaseUrl = BaseUrl;
  });
  ApiDataContext___ctor$.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.BaseUrl < that.BaseUrl) ? -1.000000 : ((this.BaseUrl == that.BaseUrl) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  ApiRequest__AddParameter$ = (function (__, key, value)
  {
    __.parameters = FSharpMap_2_IComparable__Object__Add$IComparable__Object_(__.parameters, key, value);
  });
  ApiRequest__BuildUrl$ = (function (__, dc)
  {
    var _2930;
    var _2931;
    var sep = "/";
    _2931 = (function (strings)
    {
      return FSharpString__Concat$(sep, Seq__OfArray$String_String(strings));
    });
    var _3059;
    var _3060;
    var mapping = (function (part)
    {
      if ((part.Tag == 1.000000)) 
      {
        var name = part.Item1;
        return FSharpMap_2_IComparable__Object__get_Item$IComparable__Object_(__.parameters, name);
      }
      else
      {
        var section = part.Item;
        return section;
      };
    });
    _3060 = (function (array)
    {
      return Array__Map$UrlPart__String_UrlPart__String(mapping, array);
    });
    _3059 = _3060(__.urlParts);
    _2930 = _2931(_3059);
    return (dc.BaseUrl + _2930);
  });
  ApiRequest__Send$ = (function (req, dc)
  {
    return (function (builder_)
    {
      return AsyncBuilder__Delay$FSharpOption_1_String_FSharpOption_1_String_(builder_, (function (unitVar)
      {
        var httpReq = WebRequest__Create$(ApiRequest__BuildUrl$(req, dc));
        WebRequest__set_Method$(httpReq, req.httpMethod);
        var _3125;
        var action = (function (key)
        {
          return (function (value)
          {
            return WebHeaderCollection__Add$(WebRequest__get_Headers$(httpReq), key, value);
          });
        });
        _3125 = (function (table)
        {
          return Map__Iterate$String__String_String_String(action, table);
        });
        _3125(req.headers);
        var _3194;
        var _3195;
        var matchValue = req.body;
        if ((matchValue.Tag == 1.000000)) 
        {
          var bodyText = Option__GetValue$String_String(matchValue);
          _3195 = AsyncBuilder__Using$Stream_1_Unit_Stream_1_Unit_(builder_, WebRequest__GetRequestStream$(httpReq), (function (_arg1)
          {
            var input = _arg1;
            var inBytes = UTF8Encoding__GetBytes$(Replacements_1_utf8Encoding$(), bodyText);
            return AsyncBuilder__Bind$Unit__Unit_Unit__Unit_(builder_, Stream__AsyncWrite$(input, inBytes, {Tag: 0.000000}, {Tag: 0.000000}), (function (_arg2)
            {
              var _3400;
              var _3401;
              _3400 = _3401;
              return AsyncBuilder__Return$Unit_Unit_(builder_, _3400);
            }));
          }));
        }
        else
        {
          _3195 = AsyncBuilder__Zero$(builder_);
        };
        _3194 = _3195;
        return AsyncBuilder__Combine$FSharpOption_1_String_FSharpOption_1_String_(builder_, _3194, AsyncBuilder__Delay$FSharpOption_1_String_FSharpOption_1_String_(builder_, (function (_unitVar)
        {
          return AsyncBuilder__Bind$WebResponse_1_FSharpOption_1_String_WebResponse_1_FSharpOption_1_String_(builder_, WebRequest__AsyncGetResponse$(httpReq), (function (_arg3)
          {
            var httpRsp = _arg3;
            return AsyncBuilder__Using$WebResponse_1_FSharpOption_1_String_WebResponse_1_FSharpOption_1_String_(builder_, httpRsp, (function (_arg4)
            {
              var _httpRsp = _arg4;
              if ((WebResponse__get_ContentLength$(_httpRsp) > 0.000000)) 
              {
                return AsyncBuilder__Using$Stream_1_FSharpOption_1_String_Stream_1_FSharpOption_1_String_(builder_, WebResponse__GetResponseStream$(_httpRsp), (function (_arg5)
                {
                  var outputStream = _arg5;
                  return AsyncBuilder__Bind$Byte____FSharpOption_1_String_Byte____FSharpOption_1_String_(builder_, Stream__AsyncRead$(outputStream, WebResponse__get_ContentLength$(_httpRsp)), (function (_arg6)
                  {
                    var outBytes = _arg6;
                    var outText = UTF8Encoding__GetString$(Replacements_1_utf8Encoding$(), outBytes);
                    return AsyncBuilder__Return$FSharpOption_1_String_FSharpOption_1_String_(builder_, {Tag: 1.000000, Value: outText});
                  }));
                }));
              }
              else
              {
                return AsyncBuilder__Return$FSharpOption_1_String_FSharpOption_1_String_(builder_, {Tag: 0.000000});
              };
            }));
          }));
        })));
      }));
    })(Async_1_get_async$());
  });
  ApiRequest__SendAndDeserialize$ = (function (req, t, dc)
  {
    return (function (builder_)
    {
      return AsyncBuilder__Delay$Object_Object_(builder_, (function (unitVar)
      {
        return AsyncBuilder__Bind$FSharpOption_1_String__Object_FSharpOption_1_String__Object_(builder_, ApiRequest__Send$(req, dc), (function (_arg8)
        {
          var result = _arg8;
          if ((result.Tag == 1.000000)) 
          {
            var json = Option__GetValue$String_String(result);
            return AsyncBuilder__Return$Object_Object_(builder_, Serialization__deserialize$(t, json));
          }
          else
          {
            var _4349;
            var _4350;
            throw ("The response had no content.");
            _4350 = null;
            _4349 = _4350;
            return AsyncBuilder__Return$Object_Object_(builder_, _4349);
          };
        }));
      }));
    })(Async_1_get_async$());
  });
  ApiRequest___ctor$ = (function (httpMethod, urlParts)
  {
    this.httpMethod = httpMethod;
    this.urlParts = urlParts;
    this.headers = Map__Empty$String__String_String_String();
    this.parameters = Map__Empty$String__String_String_String();
    this.queryParameters = Map__Empty$String__String_String_String();
    this.body = {Tag: 0.000000};
  });
  Array__Append$Byte_Byte = (function (xs, ys)
  {
    return xs.concat(ys);;
  });
  Array__BoxedLength$ = (function (xs)
  {
    return xs.length;;
  });
  Array__CreateInstance$ = (function (_type, size)
  {
    return Array__ZeroCreate$Object_Object_(size);
  });
  Array__Fold$Char__SetTree_1_Char_Char_SetTree_1_Char_ = (function (f, seed, xs)
  {
    return Array__FoldIndexed$SetTree_1_Char__Char_SetTree_1_Char__Char((function (_arg1)
    {
      return (function (acc)
      {
        return (function (x)
        {
          return f(acc)(x);
        });
      });
    }), seed, xs);
  });
  Array__Fold$Tuple_2_String__Message__Unit_Tuple_2_String__Message__Unit_ = (function (f, seed, xs)
  {
    return Array__FoldIndexed$Unit__Tuple_2_String__Message_Unit__Tuple_2_String__Message_((function (_arg1)
    {
      return (function (acc)
      {
        return (function (x)
        {
          return f(acc)(x);
        });
      });
    }), seed, xs);
  });
  Array__FoldIndexed$SetTree_1_Char__Char_SetTree_1_Char__Char = (function (f, seed, xs)
  {
    var acc = seed;
    for (var i = 0; i <= (Array__Length$Char_Char(xs) - 1); i++)
    {
      acc = f(i)(acc)(xs[i]);
      null;
    };
    return acc;
  });
  Array__FoldIndexed$Unit__Tuple_2_String__Message_Unit__Tuple_2_String__Message_ = (function (f, seed, xs)
  {
    var acc = seed;
    for (var i = 0; i <= (Array__Length$Tuple_2_String__Message_Tuple_2_String__Message_(xs) - 1); i++)
    {
      acc = f(i)(acc)(xs[i]);
      null;
    };
    return acc;
  });
  Array__GetSubArray$Byte_Byte = (function (xs, offset, length)
  {
    return xs.slice(offset, offset + length);;
  });
  Array__Iterate$Tuple_2_String__Message_Tuple_2_String__Message_ = (function (f, xs)
  {
    var _4607;
    return Array__Fold$Tuple_2_String__Message__Unit_Tuple_2_String__Message__Unit_((function (unitVar0)
    {
      return (function (x)
      {
        return f(x);
      });
    }), _4607, xs);
  });
  Array__Length$Char_Char = (function (xs)
  {
    return xs.length;;
  });
  Array__Length$PropertyInfo_1PropertyInfo_1 = (function (xs)
  {
    return xs.length;;
  });
  Array__Length$Tuple_2_String__Message_Tuple_2_String__Message_ = (function (xs)
  {
    return xs.length;;
  });
  Array__Length$Type_1Type_1 = (function (xs)
  {
    return xs.length;;
  });
  Array__Length$UnionCaseInfo_1UnionCaseInfo_1 = (function (xs)
  {
    return xs.length;;
  });
  Array__Length$UrlPart_UrlPart_ = (function (xs)
  {
    return xs.length;;
  });
  Array__Map$PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_ = (function (f, xs)
  {
    return Array__MapIndexed$PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_((function (_arg1)
    {
      return (function (x)
      {
        return f(x);
      });
    }), xs);
  });
  Array__Map$Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_ = (function (f, xs)
  {
    return Array__MapIndexed$Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_((function (_arg1)
    {
      return (function (x)
      {
        return f(x);
      });
    }), xs);
  });
  Array__Map$UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___ = (function (f, xs)
  {
    return Array__MapIndexed$UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___((function (_arg1)
    {
      return (function (x)
      {
        return f(x);
      });
    }), xs);
  });
  Array__Map$UrlPart__String_UrlPart__String = (function (f, xs)
  {
    return Array__MapIndexed$UrlPart__String_UrlPart__String((function (_arg1)
    {
      return (function (x)
      {
        return f(x);
      });
    }), xs);
  });
  Array__MapIndexed$PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_ = (function (f, xs)
  {
    var ys = Array__ZeroCreate$Lazy_1_FSharpFunc_2_JsonReader__Object_Lazy_1_FSharpFunc_2_JsonReader__Object_(Array__Length$PropertyInfo_1PropertyInfo_1(xs));
    for (var i = 0; i <= (Array__Length$PropertyInfo_1PropertyInfo_1(xs) - 1); i++)
    {
      ys[i] = f(i)(xs[i]);
      null;
    };
    return ys;
  });
  Array__MapIndexed$PropertyInfo_1_Tuple_2_String__Int32_PropertyInfo_1_Tuple_2_String__Int32_ = (function (f, xs)
  {
    var ys = Array__ZeroCreate$Tuple_2_String__Int32_Tuple_2_String__Int32_(Array__Length$PropertyInfo_1PropertyInfo_1(xs));
    for (var i = 0; i <= (Array__Length$PropertyInfo_1PropertyInfo_1(xs) - 1); i++)
    {
      ys[i] = f(i)(xs[i]);
      null;
    };
    return ys;
  });
  Array__MapIndexed$Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_ = (function (f, xs)
  {
    var ys = Array__ZeroCreate$Lazy_1_FSharpFunc_2_JsonReader__Object_Lazy_1_FSharpFunc_2_JsonReader__Object_(Array__Length$Type_1Type_1(xs));
    for (var i = 0; i <= (Array__Length$Type_1Type_1(xs) - 1); i++)
    {
      ys[i] = f(i)(xs[i]);
      null;
    };
    return ys;
  });
  Array__MapIndexed$Type_1_Tuple_2_String__Int32_Type_1_Tuple_2_String__Int32_ = (function (f, xs)
  {
    var ys = Array__ZeroCreate$Tuple_2_String__Int32_Tuple_2_String__Int32_(Array__Length$Type_1Type_1(xs));
    for (var i = 0; i <= (Array__Length$Type_1Type_1(xs) - 1); i++)
    {
      ys[i] = f(i)(xs[i]);
      null;
    };
    return ys;
  });
  Array__MapIndexed$UnionCaseInfo_1_Tuple_2_String__Int32_UnionCaseInfo_1_Tuple_2_String__Int32_ = (function (f, xs)
  {
    var ys = Array__ZeroCreate$Tuple_2_String__Int32_Tuple_2_String__Int32_(Array__Length$UnionCaseInfo_1UnionCaseInfo_1(xs));
    for (var i = 0; i <= (Array__Length$UnionCaseInfo_1UnionCaseInfo_1(xs) - 1); i++)
    {
      ys[i] = f(i)(xs[i]);
      null;
    };
    return ys;
  });
  Array__MapIndexed$UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___ = (function (f, xs)
  {
    var ys = Array__ZeroCreate$Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___(Array__Length$UnionCaseInfo_1UnionCaseInfo_1(xs));
    for (var i = 0; i <= (Array__Length$UnionCaseInfo_1UnionCaseInfo_1(xs) - 1); i++)
    {
      ys[i] = f(i)(xs[i]);
      null;
    };
    return ys;
  });
  Array__MapIndexed$UrlPart__String_UrlPart__String = (function (f, xs)
  {
    var ys = Array__ZeroCreate$String_String(Array__Length$UrlPart_UrlPart_(xs));
    for (var i = 0; i <= (Array__Length$UrlPart_UrlPart_(xs) - 1); i++)
    {
      ys[i] = f(i)(xs[i]);
      null;
    };
    return ys;
  });
  Array__Reverse$Tuple_2_String__Message_Tuple_2_String__Message_ = (function (xs)
  {
    var size = Array__Length$Tuple_2_String__Message_Tuple_2_String__Message_(xs);
    var ys = Array__ZeroCreate$Tuple_2_String__Message_Tuple_2_String__Message_(size);
    for (var i = 0; i <= (size - 1); i++)
    {
      ys[i] = xs[((size - 1) - i)];
      null;
    };
    return ys;
  });
  Array__ZeroCreate$Lazy_1_FSharpFunc_2_JsonReader__Object_Lazy_1_FSharpFunc_2_JsonReader__Object_ = (function (size)
  {
    return new Array(size);;
  });
  Array__ZeroCreate$Object_Object_ = (function (size)
  {
    return new Array(size);;
  });
  Array__ZeroCreate$String_String = (function (size)
  {
    return new Array(size);;
  });
  Array__ZeroCreate$Tuple_2_String__Int32_Tuple_2_String__Int32_ = (function (size)
  {
    return new Array(size);;
  });
  Array__ZeroCreate$Tuple_2_String__Message_Tuple_2_String__Message_ = (function (size)
  {
    return new Array(size);;
  });
  Array__ZeroCreate$Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___ = (function (size)
  {
    return new Array(size);;
  });
  AsyncBuilder__Bind$Byte____FSharpOption_1_String_Byte____FSharpOption_1_String_ = (function (x, _arg1, f)
  {
    var v = _arg1.Item;
    return (function (_f)
    {
      return Async_1_protectedCont$FSharpOption_1_String_FSharpOption_1_String_(_f);
    })((function (k)
    {
      var cont = (function (a)
      {
        var patternInput = f(a);
        var r = patternInput.Item;
        return r(k);
      });
      return v((new AsyncParams_1_Byte_____ctor$Byte___(cont, k.Aux)));
    }));
  });
  AsyncBuilder__Bind$FSharpOption_1_String__Object_FSharpOption_1_String__Object_ = (function (x, _arg1, f)
  {
    var v = _arg1.Item;
    return (function (_f)
    {
      return Async_1_protectedCont$Object_Object_(_f);
    })((function (k)
    {
      var cont = (function (a)
      {
        var patternInput = f(a);
        var r = patternInput.Item;
        return r(k);
      });
      return v((new AsyncParams_1_FSharpOption_1_String___ctor$FSharpOption_1_String_(cont, k.Aux)));
    }));
  });
  AsyncBuilder__Bind$FSharpOption_1_Tuple_2____Unit_FSharpOption_1_Tuple_2____Unit_ = (function (x, _arg1, f)
  {
    var v = _arg1.Item;
    return (function (_f)
    {
      return Async_1_protectedCont$Unit_Unit_(_f);
    })((function (k)
    {
      var cont = (function (a)
      {
        var patternInput = f(a);
        var r = patternInput.Item;
        return r(k);
      });
      return v((new AsyncParams_1_FSharpOption_1_Tuple_2_____ctor$FSharpOption_1_Tuple_2___(cont, k.Aux)));
    }));
  });
  AsyncBuilder__Bind$Object__FSharpOption_1_Tuple_2___Object__FSharpOption_1_Tuple_2___ = (function (x, _arg1, f)
  {
    var v = _arg1.Item;
    return (function (_f)
    {
      return Async_1_protectedCont$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___(_f);
    })((function (k)
    {
      var cont = (function (a)
      {
        var patternInput = f(a);
        var r = patternInput.Item;
        return r(k);
      });
      return v((new AsyncParams_1_Object___ctor$Object_(cont, k.Aux)));
    }));
  });
  AsyncBuilder__Bind$Unit__FSharpOption_1_String_Unit__FSharpOption_1_String_ = (function (x, _arg1, f)
  {
    var v = _arg1.Item;
    return (function (_f)
    {
      return Async_1_protectedCont$FSharpOption_1_String_FSharpOption_1_String_(_f);
    })((function (k)
    {
      var cont = (function (a)
      {
        var patternInput = f(a);
        var r = patternInput.Item;
        return r(k);
      });
      return v((new AsyncParams_1_Unit___ctor$Unit_(cont, k.Aux)));
    }));
  });
  AsyncBuilder__Bind$Unit__Unit_Unit__Unit_ = (function (x, _arg1, f)
  {
    var v = _arg1.Item;
    return (function (_f)
    {
      return Async_1_protectedCont$Unit_Unit_(_f);
    })((function (k)
    {
      var cont = (function (a)
      {
        var patternInput = f(a);
        var r = patternInput.Item;
        return r(k);
      });
      return v((new AsyncParams_1_Unit___ctor$Unit_(cont, k.Aux)));
    }));
  });
  AsyncBuilder__Bind$WebResponse_1_FSharpOption_1_String_WebResponse_1_FSharpOption_1_String_ = (function (x, _arg1, f)
  {
    var v = _arg1.Item;
    return (function (_f)
    {
      return Async_1_protectedCont$FSharpOption_1_String_FSharpOption_1_String_(_f);
    })((function (k)
    {
      var cont = (function (a)
      {
        var patternInput = f(a);
        var r = patternInput.Item;
        return r(k);
      });
      return v((new AsyncParams_1_WebResponse___ctor$WebResponse_1(cont, k.Aux)));
    }));
  });
  AsyncBuilder__Combine$FSharpOption_1_String_FSharpOption_1_String_ = (function (x, work1, work2)
  {
    return AsyncBuilder__Bind$Unit__FSharpOption_1_String_Unit__FSharpOption_1_String_(x, work1, (function (unitVar0)
    {
      return work2;
    }));
  });
  AsyncBuilder__Delay$Byte___Byte___ = (function (x, f)
  {
    return (function (_f)
    {
      return Async_1_protectedCont$Byte___Byte___(_f);
    })((function (k)
    {
      var _3979;
      var _3981;
      _3979 = f(_3981);
      var patternInput = _3979;
      var r = patternInput.Item;
      return r(k);
    }));
  });
  AsyncBuilder__Delay$FSharpOption_1_String_FSharpOption_1_String_ = (function (x, f)
  {
    return (function (_f)
    {
      return Async_1_protectedCont$FSharpOption_1_String_FSharpOption_1_String_(_f);
    })((function (k)
    {
      var _4196;
      var _4198;
      _4196 = f(_4198);
      var patternInput = _4196;
      var r = patternInput.Item;
      return r(k);
    }));
  });
  AsyncBuilder__Delay$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___ = (function (x, f)
  {
    return (function (_f)
    {
      return Async_1_protectedCont$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___(_f);
    })((function (k)
    {
      var _4534;
      var _4536;
      _4534 = f(_4536);
      var patternInput = _4534;
      var r = patternInput.Item;
      return r(k);
    }));
  });
  AsyncBuilder__Delay$Object_Object_ = (function (x, f)
  {
    return (function (_f)
    {
      return Async_1_protectedCont$Object_Object_(_f);
    })((function (k)
    {
      var _4376;
      var _4378;
      _4376 = f(_4378);
      var patternInput = _4376;
      var r = patternInput.Item;
      return r(k);
    }));
  });
  AsyncBuilder__Delay$Unit_Unit_ = (function (x, f)
  {
    return (function (_f)
    {
      return Async_1_protectedCont$Unit_Unit_(_f);
    })((function (k)
    {
      var _3387;
      var _3389;
      _3387 = f(_3389);
      var patternInput = _3387;
      var r = patternInput.Item;
      return r(k);
    }));
  });
  AsyncBuilder__Return$Byte___Byte___ = (function (x, v)
  {
    return (function (f)
    {
      return Async_1_protectedCont$Byte___Byte___(f);
    })((function (k)
    {
      return Async_1_invokeCont$Byte___Byte___(k, v);
    }));
  });
  AsyncBuilder__Return$FSharpOption_1_String_FSharpOption_1_String_ = (function (x, v)
  {
    return (function (f)
    {
      return Async_1_protectedCont$FSharpOption_1_String_FSharpOption_1_String_(f);
    })((function (k)
    {
      return Async_1_invokeCont$FSharpOption_1_String_FSharpOption_1_String_(k, v);
    }));
  });
  AsyncBuilder__Return$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___ = (function (x, v)
  {
    return (function (f)
    {
      return Async_1_protectedCont$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___(f);
    })((function (k)
    {
      return Async_1_invokeCont$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___(k, v);
    }));
  });
  AsyncBuilder__Return$Object_Object_ = (function (x, v)
  {
    return (function (f)
    {
      return Async_1_protectedCont$Object_Object_(f);
    })((function (k)
    {
      return Async_1_invokeCont$Object_Object_(k, v);
    }));
  });
  AsyncBuilder__Return$Unit_Unit_ = (function (x, v)
  {
    return (function (f)
    {
      return Async_1_protectedCont$Unit_Unit_(f);
    })((function (k)
    {
      return Async_1_invokeCont$Unit_Unit_(k, v);
    }));
  });
  AsyncBuilder__ReturnFrom$Unit_Unit_ = (function (x, w)
  {
    return w;
  });
  AsyncBuilder__Using$Stream_1_FSharpOption_1_String_Stream_1_FSharpOption_1_String_ = (function (x, a, f)
  {
    return (function (_f)
    {
      return Async_1_protectedCont$FSharpOption_1_String_FSharpOption_1_String_(_f);
    })((function (k)
    {
      var patternInput = f(a);
      var v = patternInput.Item;
      var _4135;
      var impl;
      impl = a;
      _4135 = {Dispose: (function (unitVar1)
      {
        return (function (__, unitVar1)
        {
          ;
        })(impl, unitVar1);
      })};
      var resource = _4135;
      return v((new AsyncParams_1_FSharpOption_1_String___ctor$FSharpOption_1_String_((function (_x)
      {
        resource.Dispose();
        return k.Cont(_x);
      }), k.Aux)));
    }));
  });
  AsyncBuilder__Using$Stream_1_Unit_Stream_1_Unit_ = (function (x, a, f)
  {
    return (function (_f)
    {
      return Async_1_protectedCont$Unit_Unit_(_f);
    })((function (k)
    {
      var patternInput = f(a);
      var v = patternInput.Item;
      var _3437;
      var impl;
      impl = a;
      _3437 = {Dispose: (function (unitVar1)
      {
        return (function (__, unitVar1)
        {
          ;
        })(impl, unitVar1);
      })};
      var resource = _3437;
      return v((new AsyncParams_1_Unit___ctor$Unit_((function (_x)
      {
        resource.Dispose();
        return k.Cont(_x);
      }), k.Aux)));
    }));
  });
  AsyncBuilder__Using$WebResponse_1_FSharpOption_1_String_WebResponse_1_FSharpOption_1_String_ = (function (x, a, f)
  {
    return (function (_f)
    {
      return Async_1_protectedCont$FSharpOption_1_String_FSharpOption_1_String_(_f);
    })((function (k)
    {
      var patternInput = f(a);
      var v = patternInput.Item;
      var _4160;
      var impl;
      impl = a;
      _4160 = {Dispose: (function (unitVar1)
      {
        return (function (__, unitVar1)
        {
          ;
        })(impl, unitVar1);
      })};
      var resource = _4160;
      return v((new AsyncParams_1_FSharpOption_1_String___ctor$FSharpOption_1_String_((function (_x)
      {
        resource.Dispose();
        return k.Cont(_x);
      }), k.Aux)));
    }));
  });
  AsyncBuilder__Zero$ = (function (x, unitVar1)
  {
    return (function (f)
    {
      return Async_1_protectedCont$Unit_Unit_(f);
    })((function (k)
    {
      var _3379;
      return Async_1_invokeCont$Unit_Unit_(k, _3379);
    }));
  });
  AsyncBuilder___ctor$ = (function (unitVar0)
  {
    ;
  });
  AsyncExtensions__Map$Object__FSharpOption_1_Tuple_2___Object__FSharpOption_1_Tuple_2___ = (function (xAsync, f)
  {
    return (function (builder_)
    {
      return AsyncBuilder__Delay$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___(builder_, (function (unitVar)
      {
        return AsyncBuilder__Bind$Object__FSharpOption_1_Tuple_2___Object__FSharpOption_1_Tuple_2___(builder_, xAsync, (function (_arg1)
        {
          var x = _arg1;
          return AsyncBuilder__Return$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___(builder_, f(x));
        }));
      }));
    })(Async_1_get_async$());
  });
  AsyncParamsAux___ctor$ = (function (StackCounter, ExceptionCont, CancelledCont, CancellationToken)
  {
    this.StackCounter = StackCounter;
    this.ExceptionCont = ExceptionCont;
    this.CancelledCont = CancelledCont;
    this.CancellationToken = CancellationToken;
  });
  AsyncParamsAux___ctor$.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.StackCounter.CompareTo(that.StackCounter);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.ExceptionCont.CompareTo(that.ExceptionCont);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.CancelledCont.CompareTo(that.CancelledCont);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          var ____diff = 0.000000;
          ____diff = this.CancellationToken.CompareTo(that.CancellationToken);
          diff = ____diff;
          if ((diff != 0.000000)) 
          {
            return diff;
          }
          else
          {
            return 0.000000;
          };
        };
      };
    };
  });
  AsyncParams_1_Byte_____ctor$Byte___ = (function (Cont, Aux)
  {
    this.Cont = Cont;
    this.Aux = Aux;
  });
  AsyncParams_1_Byte_____ctor$Byte___.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Cont.CompareTo(that.Cont);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Aux.CompareTo(that.Aux);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  AsyncParams_1_FSharpOption_1_String___ctor$FSharpOption_1_String_ = (function (Cont, Aux)
  {
    this.Cont = Cont;
    this.Aux = Aux;
  });
  AsyncParams_1_FSharpOption_1_String___ctor$FSharpOption_1_String_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Cont.CompareTo(that.Cont);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Aux.CompareTo(that.Aux);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  AsyncParams_1_FSharpOption_1_Tuple_2_____ctor$FSharpOption_1_Tuple_2___ = (function (Cont, Aux)
  {
    this.Cont = Cont;
    this.Aux = Aux;
  });
  AsyncParams_1_FSharpOption_1_Tuple_2_____ctor$FSharpOption_1_Tuple_2___.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Cont.CompareTo(that.Cont);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Aux.CompareTo(that.Aux);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  AsyncParams_1_Object___ctor$Object_ = (function (Cont, Aux)
  {
    this.Cont = Cont;
    this.Aux = Aux;
  });
  AsyncParams_1_Object___ctor$Object_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Cont.CompareTo(that.Cont);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Aux.CompareTo(that.Aux);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  AsyncParams_1_Unit___ctor$Unit_ = (function (Cont, Aux)
  {
    this.Cont = Cont;
    this.Aux = Aux;
  });
  AsyncParams_1_Unit___ctor$Unit_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Cont.CompareTo(that.Cont);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Aux.CompareTo(that.Aux);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  AsyncParams_1_WebResponse___ctor$WebResponse_1 = (function (Cont, Aux)
  {
    this.Cont = Cont;
    this.Aux = Aux;
  });
  AsyncParams_1_WebResponse___ctor$WebResponse_1.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Cont.CompareTo(that.Cont);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Aux.CompareTo(that.Aux);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  Async_1_Byte____ContByte___ = (function (Item)
  {
    this.Tag = 0.000000;
    this._CaseName = "Cont";
    this.Item = Item;
  });
  Async_1_Byte____ContByte___.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item.CompareTo(that.Item);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  Async_1_FSharpOption_1_String__ContFSharpOption_1_String_ = (function (Item)
  {
    this.Tag = 0.000000;
    this._CaseName = "Cont";
    this.Item = Item;
  });
  Async_1_FSharpOption_1_String__ContFSharpOption_1_String_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item.CompareTo(that.Item);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  Async_1_FSharpOption_1_Tuple_2____ContFSharpOption_1_Tuple_2___ = (function (Item)
  {
    this.Tag = 0.000000;
    this._CaseName = "Cont";
    this.Item = Item;
  });
  Async_1_FSharpOption_1_Tuple_2____ContFSharpOption_1_Tuple_2___.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item.CompareTo(that.Item);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  Async_1_Object__ContObject_ = (function (Item)
  {
    this.Tag = 0.000000;
    this._CaseName = "Cont";
    this.Item = Item;
  });
  Async_1_Object__ContObject_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item.CompareTo(that.Item);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  Async_1_Unit__ContUnit_ = (function (Item)
  {
    this.Tag = 0.000000;
    this._CaseName = "Cont";
    this.Item = Item;
  });
  Async_1_Unit__ContUnit_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item.CompareTo(that.Item);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  Async_1_WebResponse__ContWebResponse_ = (function (Item)
  {
    this.Tag = 0.000000;
    this._CaseName = "Cont";
    this.Item = Item;
  });
  Async_1_WebResponse__ContWebResponse_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item.CompareTo(that.Item);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  Async_1_get_async$ = (function ()
  {
    return (new AsyncBuilder___ctor$());
  });
  Async_1_invokeCont$Byte___Byte___ = (function (k, value)
  {
    return k.Cont(value);
  });
  Async_1_invokeCont$FSharpOption_1_String_FSharpOption_1_String_ = (function (k, value)
  {
    return k.Cont(value);
  });
  Async_1_invokeCont$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___ = (function (k, value)
  {
    return k.Cont(value);
  });
  Async_1_invokeCont$Object_Object_ = (function (k, value)
  {
    return k.Cont(value);
  });
  Async_1_invokeCont$Unit_Unit_ = (function (k, value)
  {
    return k.Cont(value);
  });
  Async_1_protectedCont$Byte___Byte___ = (function (f)
  {
    return (new Async_1_Byte____ContByte___((function (args)
    {
      CancellationToken__ThrowIfCancellationRequested$(args.Aux.CancellationToken);
      args.Aux.StackCounter.contents = (args.Aux.StackCounter.contents + 1);
      null;
      if ((args.Aux.StackCounter.contents > 1000)) 
      {
        args.Aux.StackCounter.contents = 0;
        null;
        return Async_1_setTimeout$Unit_Unit_((function (unitVar0)
        {
          return f(args);
        }), 1.000000);
      }
      else
      {
        return f(args);
      };
    })));
  });
  Async_1_protectedCont$FSharpOption_1_String_FSharpOption_1_String_ = (function (f)
  {
    return (new Async_1_FSharpOption_1_String__ContFSharpOption_1_String_((function (args)
    {
      CancellationToken__ThrowIfCancellationRequested$(args.Aux.CancellationToken);
      args.Aux.StackCounter.contents = (args.Aux.StackCounter.contents + 1);
      null;
      if ((args.Aux.StackCounter.contents > 1000)) 
      {
        args.Aux.StackCounter.contents = 0;
        null;
        return Async_1_setTimeout$Unit_Unit_((function (unitVar0)
        {
          return f(args);
        }), 1.000000);
      }
      else
      {
        return f(args);
      };
    })));
  });
  Async_1_protectedCont$FSharpOption_1_Tuple_2___FSharpOption_1_Tuple_2___ = (function (f)
  {
    return (new Async_1_FSharpOption_1_Tuple_2____ContFSharpOption_1_Tuple_2___((function (args)
    {
      CancellationToken__ThrowIfCancellationRequested$(args.Aux.CancellationToken);
      args.Aux.StackCounter.contents = (args.Aux.StackCounter.contents + 1);
      null;
      if ((args.Aux.StackCounter.contents > 1000)) 
      {
        args.Aux.StackCounter.contents = 0;
        null;
        return Async_1_setTimeout$Unit_Unit_((function (unitVar0)
        {
          return f(args);
        }), 1.000000);
      }
      else
      {
        return f(args);
      };
    })));
  });
  Async_1_protectedCont$Object_Object_ = (function (f)
  {
    return (new Async_1_Object__ContObject_((function (args)
    {
      CancellationToken__ThrowIfCancellationRequested$(args.Aux.CancellationToken);
      args.Aux.StackCounter.contents = (args.Aux.StackCounter.contents + 1);
      null;
      if ((args.Aux.StackCounter.contents > 1000)) 
      {
        args.Aux.StackCounter.contents = 0;
        null;
        return Async_1_setTimeout$Unit_Unit_((function (unitVar0)
        {
          return f(args);
        }), 1.000000);
      }
      else
      {
        return f(args);
      };
    })));
  });
  Async_1_protectedCont$Unit_Unit_ = (function (f)
  {
    return (new Async_1_Unit__ContUnit_((function (args)
    {
      CancellationToken__ThrowIfCancellationRequested$(args.Aux.CancellationToken);
      args.Aux.StackCounter.contents = (args.Aux.StackCounter.contents + 1);
      null;
      if ((args.Aux.StackCounter.contents > 1000)) 
      {
        args.Aux.StackCounter.contents = 0;
        null;
        return Async_1_setTimeout$Unit_Unit_((function (unitVar0)
        {
          return f(args);
        }), 1.000000);
      }
      else
      {
        return f(args);
      };
    })));
  });
  Async_1_protectedCont$WebResponse_WebResponse_ = (function (f)
  {
    return (new Async_1_WebResponse__ContWebResponse_((function (args)
    {
      CancellationToken__ThrowIfCancellationRequested$(args.Aux.CancellationToken);
      args.Aux.StackCounter.contents = (args.Aux.StackCounter.contents + 1);
      null;
      if ((args.Aux.StackCounter.contents > 1000)) 
      {
        args.Aux.StackCounter.contents = 0;
        null;
        return Async_1_setTimeout$Unit_Unit_((function (unitVar0)
        {
          return f(args);
        }), 1.000000);
      }
      else
      {
        return f(args);
      };
    })));
  });
  Async_1_setTimeout$Unit_Unit_ = (function (handler, milliseconds)
  {
    return setTimeout(handler, milliseconds);;
  });
  Async__FromContinuations$WebResponse_WebResponse_ = (function (f)
  {
    return (function (_f)
    {
      return Async_1_protectedCont$WebResponse_WebResponse_(_f);
    })((function (k)
    {
      return f((new TupleFSharpFunc_2_WebResponse__Unit__FSharpFunc_2_String__Unit__FSharpFunc_2_String__Unit_(k.Cont, k.Aux.ExceptionCont, k.Aux.CancelledCont)));
    }));
  });
  Async__StartImmediate$ = (function (workflow, cancellationToken)
  {
    var _34;
    if ((cancellationToken.Tag == 1.000000)) 
    {
      var v = Option__GetValue$CancellationToken_CancellationToken_(cancellationToken);
      _34 = v;
    }
    else
    {
      _34 = (new CancellationToken___ctor$({Tag: 0.000000}));
    };
    var token = _34;
    var f = workflow.Item;
    var aux = (new AsyncParamsAux___ctor$({contents: 0}, (function (value)
    {
      var ignored0 = value;
    }), (function (value)
    {
      var ignored0 = value;
    }), token));
    return f((new AsyncParams_1_Unit___ctor$Unit_((function (value)
    {
      var ignored0 = value;
    }), aux)));
  });
  CancellationToken__ThrowIfCancellationRequested$ = (function (x, unitVar1)
  {
    var matchValue = x.Cell;
    if ((matchValue.Tag == 1.000000)) 
    {
      var _3280;
      var cell = Option__GetValue$FSharpRef_1_Boolean_FSharpRef_1_Boolean_(matchValue);
      _3280 = cell.contents;
      if (_3280) 
      {
        var _cell = Option__GetValue$FSharpRef_1_Boolean_FSharpRef_1_Boolean_(matchValue);
        throw ("OperationCancelledException");
        return null;
      }
      else
      {
        ;
      };
    }
    else
    {
      ;
    };
  });
  CancellationToken___ctor$ = (function (Cell)
  {
    this.Cell = Cell;
  });
  CancellationToken___ctor$.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Cell.CompareTo(that.Cell);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  ConcurrentDictionary_2_Object__Object__Create$Object__Object_ = (function (unitVar0)
  {
    return (new ConcurrentDictionary_2_Object__Object___ctor$Object__Object_());
  });
  ConcurrentDictionary_2_Object__Object__GetOrAdd$Object__Object_ = (function (__, key, valueFactory)
  {
    var id = Dictionaries__getUniqueObjectId$(key);
    var matchValue = FSharpMap_2_Int32__Object__TryFind$Int32_Object_(__.innerCache, id);
    if ((matchValue.Tag == 1.000000)) 
    {
      var v = Option__GetValue$Object_Object_(matchValue);
      return v;
    }
    else
    {
      var value = valueFactory(key);
      __.innerCache = FSharpMap_2_Int32__Object__Add$Int32_Object_(__.innerCache, id, value);
      return value;
    };
  });
  ConcurrentDictionary_2_Object__Object___ctor$Object__Object_ = (function (unitVar0)
  {
    this.innerCache = Map__Empty$Int32__Object_Int32_Object_();
  });
  CreateEnumerable_1_String___ctor$String = (function (factory)
  {
    this.factory = factory;
  });
  Dictionaries__getProperty$Int32_Int32 = (function (x, prop)
  {
    return x[prop];;
  });
  Dictionaries__getUniqueObjectId$ = (function (x)
  {
    var objId = "FunScriptObjectId";
    if (Dictionaries__hasProperty$Boolean_Boolean(x, objId)) 
    {
      return Dictionaries__getProperty$Int32_Int32(x, objId);
    }
    else
    {
      Dictionaries__nextId.contents = (Dictionaries__nextId.contents + 1);
      null;
      var thisId = Dictionaries__nextId.contents;
      Dictionaries__setProperty$Unit_Unit_(x, objId, thisId);
      return thisId;
    };
  });
  Dictionaries__get_nextId$ = (function ()
  {
    return {contents: 0};
  });
  Dictionaries__hasProperty$Boolean_Boolean = (function (x, prop)
  {
    return x[prop] !== undefined;;
  });
  Dictionaries__setProperty$Unit_Unit_ = (function (x, prop, value)
  {
    x[prop] = value;;
  });
  FSharpMap_2_IComparable__Object__Add$IComparable__Object_ = (function (m, k, v)
  {
    return (new FSharpMap_2_IComparable__Object___ctor$IComparable__Object_(m.comparer_386, MapTreeModule__add$IComparable__Object_IComparable__Object_(m.comparer_386, k, v, m.tree_390)));
  });
  FSharpMap_2_IComparable__Object__TryFind$IComparable__Object_ = (function (m, k)
  {
    return MapTreeModule__tryFind$IComparable__Object_IComparable__Object_(m.comparer_386, k, m.tree_390);
  });
  FSharpMap_2_IComparable__Object___ctor$IComparable__Object_ = (function (comparer, tree)
  {
    this.comparer_386 = comparer;
    this.tree_390 = tree;
  });
  FSharpMap_2_IComparable__Object__get_Item$IComparable__Object_ = (function (m, k)
  {
    return MapTreeModule__find$IComparable__Object_IComparable__Object_(m.comparer_386, k, m.tree_390);
  });
  FSharpMap_2_Int32__Object__Add$Int32_Object_ = (function (m, k, v)
  {
    return (new FSharpMap_2_Int32__Object___ctor$Int32_Object_(m.comparer_386, MapTreeModule__add$Int32__Object_Int32_Object_(m.comparer_386, k, v, m.tree_390)));
  });
  FSharpMap_2_Int32__Object__TryFind$Int32_Object_ = (function (m, k)
  {
    return MapTreeModule__tryFind$Int32__Object_Int32_Object_(m.comparer_386, k, m.tree_390);
  });
  FSharpMap_2_Int32__Object___ctor$Int32_Object_ = (function (comparer, tree)
  {
    this.comparer_386 = comparer;
    this.tree_390 = tree;
  });
  FSharpMap_2_Int32__Object__get_Empty$Int32_Object_ = (function (unitVar0)
  {
    var comparer = (new GenericComparer_1_Int32___ctor$Int32());
    var _1787;
    var impl;
    impl = comparer;
    _1787 = {Compare: (function (x, y)
    {
      return (function (__, x, y)
      {
        var diff = 0.000000;
        diff = ((x < y) ? -1.000000 : ((x == y) ? 0.000000 : 1.000000));
        return diff;
      })(impl, x, y);
    })};
    return (new FSharpMap_2_Int32__Object___ctor$Int32_Object_(_1787, (new MapTree_2_Int32__Object__MapEmptyInt32_Object_())));
  });
  FSharpMap_2_String__FSharpFunc_2_String__Object___ctor$String_FSharpFunc_2_String__Object_ = (function (comparer, tree)
  {
    this.comparer_386 = comparer;
    this.tree_390 = tree;
  });
  FSharpMap_2_String__FSharpFunc_2_String__Object__get_Empty$String_FSharpFunc_2_String__Object_ = (function (unitVar0)
  {
    var comparer = (new GenericComparer_1_String___ctor$String());
    var _226;
    var impl;
    impl = comparer;
    _226 = {Compare: (function (x, y)
    {
      return (function (__, x, y)
      {
        var diff = 0.000000;
        diff = ((x < y) ? -1.000000 : ((x == y) ? 0.000000 : 1.000000));
        return diff;
      })(impl, x, y);
    })};
    return (new FSharpMap_2_String__FSharpFunc_2_String__Object___ctor$String_FSharpFunc_2_String__Object_(_226, (new MapTree_2_String__FSharpFunc_2_String__Object__MapEmptyString_FSharpFunc_2_String__Object_())));
  });
  FSharpMap_2_String__Int32___ctor$String_Int32 = (function (comparer, tree)
  {
    this.comparer_386 = comparer;
    this.tree_390 = tree;
  });
  FSharpMap_2_String__String__Iterate$String_String = (function (m, f)
  {
    return MapTreeModule__iter$String__String_String_String(f, m.tree_390);
  });
  FSharpMap_2_String__String___ctor$String_String = (function (comparer, tree)
  {
    this.comparer_386 = comparer;
    this.tree_390 = tree;
  });
  FSharpMap_2_String__String__get_Empty$String_String = (function (unitVar0)
  {
    var comparer = (new GenericComparer_1_String___ctor$String());
    var _2753;
    var impl;
    impl = comparer;
    _2753 = {Compare: (function (x, y)
    {
      return (function (__, x, y)
      {
        var diff = 0.000000;
        diff = ((x < y) ? -1.000000 : ((x == y) ? 0.000000 : 1.000000));
        return diff;
      })(impl, x, y);
    })};
    return (new FSharpMap_2_String__String___ctor$String_String(_2753, (new MapTree_2_String__String__MapEmptyString_String())));
  });
  FSharpString__Concat$ = (function (sep, strings)
  {
    return String_1_Join$(sep, Seq__ToArray$String_String(strings));
  });
  FSharpType__GetRecordFields$ = (function (t, _arg4)
  {
    var matchValue = Type__get_Kind$(t);
    if ((matchValue.Tag == 1.000000)) 
    {
      var pis = matchValue.Item2;
      return pis;
    }
    else
    {
      throw ("Not a record type.");
      return null;
    };
  });
  FSharpType__GetTupleElements$ = (function (t)
  {
    var matchValue = Type__get_Kind$(t);
    if ((matchValue.Tag == 3.000000)) 
    {
      var ts = matchValue.Item2;
      return ts;
    }
    else
    {
      throw ("Not a tuple type.");
      return null;
    };
  });
  FSharpType__GetUnionCases$ = (function (t, _arg3)
  {
    var matchValue = Type__get_Kind$(t);
    if ((matchValue.Tag == 2.000000)) 
    {
      var ucis = matchValue.Item;
      return ucis;
    }
    else
    {
      throw ("Not a union type.");
      return null;
    };
  });
  FSharpType__IsRecord$ = (function (t, _arg2)
  {
    var matchValue = Type__get_Kind$(t);
    return ((matchValue.Tag == 1.000000) && true);
  });
  FSharpType__IsTuple$ = (function (t)
  {
    var matchValue = Type__get_Kind$(t);
    return ((matchValue.Tag == 3.000000) && true);
  });
  FSharpType__IsUnion$ = (function (t, _arg1)
  {
    var matchValue = Type__get_Kind$(t);
    return ((matchValue.Tag == 2.000000) && true);
  });
  FSharpValue__MakeRecord$ = (function (t, args, _arg3)
  {
    var matchValue = Type__get_Kind$(t);
    if ((matchValue.Tag == 1.000000)) 
    {
      var cons = matchValue.Item1;
      return cons(args);
    }
    else
    {
      throw ("Not a record type.");
      return null;
    };
  });
  FSharpValue__MakeTuple$ = (function (args, t)
  {
    var matchValue = Type__get_Kind$(t);
    if ((matchValue.Tag == 3.000000)) 
    {
      var c = matchValue.Item1;
      return c(args);
    }
    else
    {
      throw ("Not a tuple type.");
      return null;
    };
  });
  FSharpValue__MakeUnion$ = (function (uci, args, _arg2)
  {
    return UnionCaseInfo__Construct$(uci, args);
  });
  FSharpValue__PreComputeRecordConstructor$ = (function (t, flags)
  {
    return (function (args)
    {
      return FSharpValue__MakeRecord$(t, args, flags);
    });
  });
  FSharpValue__PreComputeTupleConstructor$ = (function (t)
  {
    return (function (args)
    {
      return FSharpValue__MakeTuple$(args, t);
    });
  });
  FSharpValue__PreComputeUnionConstructor$ = (function (uci, flags)
  {
    return (function (args)
    {
      return FSharpValue__MakeUnion$(uci, args, flags);
    });
  });
  GenericComparer_1_Char___ctor$Char = (function (unitVar0)
  {
    ;
  });
  GenericComparer_1_Int32___ctor$Int32 = (function (unitVar0)
  {
    ;
  });
  GenericComparer_1_String___ctor$String = (function (unitVar0)
  {
    ;
  });
  JsonReaderHelpers__readJsonObject$Object_Object_ = (function (positions, readers, jr)
  {
    JsonReader__MovePast$(jr, "{");
    var args = Array__ZeroCreate$Object_Object_(Array__BoxedLength$(readers));
    for (var i = 0; i <= (Array__BoxedLength$(args) - 1); i++)
    {
      if ((i != 0)) 
      {
        JsonReader__MovePast$(jr, ",");
      }
      else
      {
        ;
      };
      JsonReader__MovePast$(jr, "\"");
      var name = JsonReader__ReadUpToQuoteMark$(jr);
      var position = FSharpMap_2_IComparable__Object__get_Item$IComparable__Object_(positions, name);
      var readArg = readers[position];
      JsonReader__MovePast$(jr, "\"");
      JsonReader__MovePast$(jr, ":");
      var arg = Lazy_1_Object__get_Value$Object_(readArg)(jr);
      args[position] = arg;
      null;
    };
    JsonReader__MovePast$(jr, "}");
    return args;
  });
  JsonReaderHelpers__readValue$Boolean_Boolean = (function (parse, jr)
  {
    JsonReader__MovePastWhiteSpace$(jr);
    var stringValue = JsonReader__ReadUpToSeparatorInclWhiteSpace$(jr);
    return (function (value)
    {
      return value;
    })(parse(stringValue));
  });
  JsonReaderHelpers__readValue$Decimal_Decimal = (function (parse, jr)
  {
    JsonReader__MovePastWhiteSpace$(jr);
    var stringValue = JsonReader__ReadUpToSeparatorInclWhiteSpace$(jr);
    return (function (value)
    {
      return value;
    })(parse(stringValue));
  });
  JsonReaderHelpers__readValue$Double_Double = (function (parse, jr)
  {
    JsonReader__MovePastWhiteSpace$(jr);
    var stringValue = JsonReader__ReadUpToSeparatorInclWhiteSpace$(jr);
    return (function (value)
    {
      return value;
    })(parse(stringValue));
  });
  JsonReaderHelpers__readValue$Int32_Int32 = (function (parse, jr)
  {
    JsonReader__MovePastWhiteSpace$(jr);
    var stringValue = JsonReader__ReadUpToSeparatorInclWhiteSpace$(jr);
    return (function (value)
    {
      return value;
    })(parse(stringValue));
  });
  JsonReaderHelpers__readValue$Int64_Int64 = (function (parse, jr)
  {
    JsonReader__MovePastWhiteSpace$(jr);
    var stringValue = JsonReader__ReadUpToSeparatorInclWhiteSpace$(jr);
    return (function (value)
    {
      return value;
    })(parse(stringValue));
  });
  JsonReaderHelpers__readValue$UInt32_UInt32 = (function (parse, jr)
  {
    JsonReader__MovePastWhiteSpace$(jr);
    var stringValue = JsonReader__ReadUpToSeparatorInclWhiteSpace$(jr);
    return (function (value)
    {
      return value;
    })(parse(stringValue));
  });
  JsonReader__MovePast$ = (function (__, _char)
  {
    return JsonReader__consumeWhiteSpaceUpToIncl$(__, _char);
  });
  JsonReader__MovePastWhiteSpace$ = (function (__, unitVar1)
  {
    var _1205;
    var arg10_ = _1205;
    return JsonReader__consumeWhiteSpace$(__);
  });
  JsonReader__Peek$ = (function (__, unitVar1)
  {
    var _1362;
    var _1363;
    var arg10_ = _1363;
    _1362 = JsonReader__tryPeek$(__);
    var matchValue = _1362;
    if ((matchValue.Tag == 0.000000)) 
    {
      throw ("Out of range.");
      return null;
    }
    else
    {
      var c = Option__GetValue$Char_Char(matchValue);
      return c;
    };
  });
  JsonReader__ReadUpToQuoteMark$ = (function (__, unitVar1)
  {
    var charSet = __.quoteMarks;
    return JsonReader__readUpToExcl$(__, charSet);
  });
  JsonReader__ReadUpToSeparatorInclWhiteSpace$ = (function (__, unitVar1)
  {
    var charSet = __.separators;
    return JsonReader__readUpToExcl$(__, charSet);
  });
  JsonReader___ctor$ = (function (jsonStr)
  {
    this.jsonStr = jsonStr;
    this.position = 0;
    var _2181;
    var chars = [",", "}", "]", " ", "\t", "\r", "\n"];
    _2181 = (function (array)
    {
      return Set__OfArray$Char_Char(array);
    })(chars);
    this.separators = _2181;
    var _2456;
    var _chars = ["\""];
    _2456 = (function (array)
    {
      return Set__OfArray$Char_Char(array);
    })(_chars);
    this.quoteMarks = _2456;
  });
  JsonReader__consume$ = (function (_this, unitVar0)
  {
    _this.position = (_this.position + 1);
  });
  JsonReader__consumeWhiteSpace$ = (function (_this, unitVar0)
  {
    var _1207;
    var _1208;
    var arg10_ = _1208;
    _1207 = JsonReader__tryPeek$(_this);
    var matchValue = _1207;
    if ((matchValue.Tag == 1.000000)) 
    {
      var c = Option__GetValue$Char_Char(matchValue);
      if ((c == "\t")) 
      {
        var _1218;
        var _arg10_ = _1218;
        JsonReader__consume$(_this);
        var _1222;
        return (function (__arg10_)
        {
          return JsonReader__consumeWhiteSpace$(_this);
        })(_1222);
      }
      else
      {
        if ((c == "\n")) 
        {
          var _1226;
          var __arg10_ = _1226;
          JsonReader__consume$(_this);
          var _1230;
          return (function (___arg10_)
          {
            return JsonReader__consumeWhiteSpace$(_this);
          })(_1230);
        }
        else
        {
          if ((c == "\r")) 
          {
            var _1234;
            var ___arg10_ = _1234;
            JsonReader__consume$(_this);
            var _1238;
            return (function (____arg10_)
            {
              return JsonReader__consumeWhiteSpace$(_this);
            })(_1238);
          }
          else
          {
            if ((c == " ")) 
            {
              var _1242;
              var ____arg10_ = _1242;
              JsonReader__consume$(_this);
              var _1246;
              return (function (_____arg10_)
              {
                return JsonReader__consumeWhiteSpace$(_this);
              })(_1246);
            }
            else
            {
              ;
            };
          };
        };
      };
    }
    else
    {
      throw ("Out of range.");
      return null;
    };
  });
  JsonReader__consumeWhiteSpaceUpToIncl$ = (function (_this, _char)
  {
    var _720;
    var _721;
    var arg10_ = _721;
    _720 = JsonReader__tryConsume$(_this);
    var matchValue = _720;
    if ((matchValue.Tag == 1.000000)) 
    {
      var c = Option__GetValue$Char_Char(matchValue);
      if ((c == "\t")) 
      {
        return (function (__char)
        {
          return JsonReader__consumeWhiteSpaceUpToIncl$(_this, __char);
        })(_char);
      }
      else
      {
        if ((c == "\n")) 
        {
          return (function (__char)
          {
            return JsonReader__consumeWhiteSpaceUpToIncl$(_this, __char);
          })(_char);
        }
        else
        {
          if ((c == "\r")) 
          {
            return (function (__char)
            {
              return JsonReader__consumeWhiteSpaceUpToIncl$(_this, __char);
            })(_char);
          }
          else
          {
            if ((c == " ")) 
            {
              return (function (__char)
              {
                return JsonReader__consumeWhiteSpaceUpToIncl$(_this, __char);
              })(_char);
            }
            else
            {
              if ((c == _char)) 
              {
                ;
              }
              else
              {
                throw (("Unexpected character: " + c.toString()));
                return null;
              };
            };
          };
        };
      };
    }
    else
    {
      throw ("Out of range.");
      return null;
    };
  });
  JsonReader__readUpToExcl$ = (function (_this, charSet)
  {
    var readUpToExcl;
    readUpToExcl = (function (count)
    {
      var _821;
      var _822;
      var arg10_ = _822;
      _821 = JsonReader__tryPeek$(_this);
      var nextC = _821;
      if ((nextC.Tag == 1.000000)) 
      {
        var _840;
        var c = Option__GetValue$Char_Char(nextC);
        _840 = (function (set)
        {
          return Set__Contains$Char_Char(c, set);
        })(charSet);
        if (_840) 
        {
          var _c = Option__GetValue$Char_Char(nextC);
          return count;
        }
        else
        {
          if ((nextC.Tag == 1.000000)) 
          {
            var _901;
            var _arg10_ = _901;
            JsonReader__consume$(_this);
            return readUpToExcl((count + 1));
          }
          else
          {
            throw ("Out of range.");
            return null;
          };
        };
      }
      else
      {
        if ((nextC.Tag == 1.000000)) 
        {
          var _915;
          var __arg10_ = _915;
          JsonReader__consume$(_this);
          return readUpToExcl((count + 1));
        }
        else
        {
          throw ("Out of range.");
          return null;
        };
      };
    });
    var startPosition = _this.position;
    var count = readUpToExcl(0);
    return String_1_Substring$(_this.jsonStr, startPosition, count);
  });
  JsonReader__tryConsume$ = (function (_this, unitVar0)
  {
    if ((_this.position < String_1_Length$(_this.jsonStr))) 
    {
      var _char = String_1_CharAt$(_this.jsonStr, _this.position);
      _this.position = (_this.position + 1);
      return {Tag: 1.000000, Value: _char};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  JsonReader__tryPeek$ = (function (_this, unitVar0)
  {
    if ((_this.position < String_1_Length$(_this.jsonStr))) 
    {
      return {Tag: 1.000000, Value: String_1_CharAt$(_this.jsonStr, _this.position)};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  Lazy_1_Object__Create$Object_ = (function (f)
  {
    return (new Lazy_1_Object___ctor$Object_(null, f));
  });
  Lazy_1_Object___ctor$Object_ = (function (value, factory)
  {
    this.factory = factory;
    this.isCreated = false;
    this.value_25 = value;
  });
  Lazy_1_Object__get_Value$Object_ = (function (x, unitVar1)
  {
    if ((!x.isCreated)) 
    {
      var _90;
      var _93;
      _90 = x.factory(_93);
      x.value_25 = _90;
      x.isCreated = true;
    }
    else
    {
      ;
    };
    return x.value_25;
  });
  List__CreateCons$Object_Object_ = (function (x, xs)
  {
    return (new list_1_Object__ConsObject_(x, xs));
  });
  List__CreateCons$Tuple_2_String__String_Tuple_2_String__String_ = (function (x, xs)
  {
    return (new list_1_Tuple_2_String__String__ConsTuple_2_String__String_(x, xs));
  });
  List__Empty$Object_Object_ = (function ()
  {
    return (new list_1_Object__NilObject_());
  });
  List__Empty$Tuple_2_String__String_Tuple_2_String__String_ = (function ()
  {
    return (new list_1_Tuple_2_String__String__NilTuple_2_String__String_());
  });
  List__Fold$Object__Int32_Object__Int32 = (function (f, seed, xs)
  {
    return List__FoldIndexed$Object__Int32_Object__Int32((function (_arg1)
    {
      return (function (acc)
      {
        return (function (x)
        {
          return f(acc)(x);
        });
      });
    }), seed, xs);
  });
  List__Fold$String__Int32_String_Int32 = (function (f, seed, xs)
  {
    return List__FoldIndexed$String__Int32_String_Int32((function (_arg1)
    {
      return (function (acc)
      {
        return (function (x)
        {
          return f(acc)(x);
        });
      });
    }), seed, xs);
  });
  List__Fold$String__list_1_String_String_list_1_String_ = (function (f, seed, xs)
  {
    return List__FoldIndexed$String__list_1_String_String_list_1_String_((function (_arg1)
    {
      return (function (acc)
      {
        return (function (x)
        {
          return f(acc)(x);
        });
      });
    }), seed, xs);
  });
  List__Fold$Tuple_2_String__String__list_1_String_Tuple_2_String__String__list_1_String_ = (function (f, seed, xs)
  {
    return List__FoldIndexed$Tuple_2_String__String__list_1_String_Tuple_2_String__String__list_1_String_((function (_arg1)
    {
      return (function (acc)
      {
        return (function (x)
        {
          return f(acc)(x);
        });
      });
    }), seed, xs);
  });
  List__FoldIndexed$Object__Int32_Object__Int32 = (function (f, seed, xs)
  {
    return List__FoldIndexedAux$Int32__Object_Int32_Object_(f, 0, seed, xs);
  });
  List__FoldIndexed$Object__Unit_Object__Unit_ = (function (f, seed, xs)
  {
    return List__FoldIndexedAux$Unit__Object_Unit__Object_(f, 0, seed, xs);
  });
  List__FoldIndexed$String__Int32_String_Int32 = (function (f, seed, xs)
  {
    return List__FoldIndexedAux$Int32__String_Int32_String(f, 0, seed, xs);
  });
  List__FoldIndexed$String__Unit_String_Unit_ = (function (f, seed, xs)
  {
    return List__FoldIndexedAux$Unit__String_Unit__String(f, 0, seed, xs);
  });
  List__FoldIndexed$String__list_1_String_String_list_1_String_ = (function (f, seed, xs)
  {
    return List__FoldIndexedAux$list_1_String__String_list_1_String__String(f, 0, seed, xs);
  });
  List__FoldIndexed$Tuple_2_String__String__list_1_String_Tuple_2_String__String__list_1_String_ = (function (f, seed, xs)
  {
    return List__FoldIndexedAux$list_1_String__Tuple_2_String__String_list_1_String__Tuple_2_String__String_(f, 0, seed, xs);
  });
  List__FoldIndexedAux$Int32__Object_Int32_Object_ = (function (f, i, acc, _arg1)
  {
    if ((_arg1.Tag == 1.000000)) 
    {
      var xs = _arg1.Item2;
      var x = _arg1.Item1;
      return List__FoldIndexedAux$Int32__Object_Int32_Object_(f, (i + 1), f(i)(acc)(x), xs);
    }
    else
    {
      return acc;
    };
  });
  List__FoldIndexedAux$Int32__String_Int32_String = (function (f, i, acc, _arg1)
  {
    if ((_arg1.Tag == 1.000000)) 
    {
      var xs = _arg1.Item2;
      var x = _arg1.Item1;
      return List__FoldIndexedAux$Int32__String_Int32_String(f, (i + 1), f(i)(acc)(x), xs);
    }
    else
    {
      return acc;
    };
  });
  List__FoldIndexedAux$Unit__Object_Unit__Object_ = (function (f, i, acc, _arg1)
  {
    if ((_arg1.Tag == 1.000000)) 
    {
      var xs = _arg1.Item2;
      var x = _arg1.Item1;
      return List__FoldIndexedAux$Unit__Object_Unit__Object_(f, (i + 1), f(i)(acc)(x), xs);
    }
    else
    {
      return acc;
    };
  });
  List__FoldIndexedAux$Unit__String_Unit__String = (function (f, i, acc, _arg1)
  {
    if ((_arg1.Tag == 1.000000)) 
    {
      var xs = _arg1.Item2;
      var x = _arg1.Item1;
      return List__FoldIndexedAux$Unit__String_Unit__String(f, (i + 1), f(i)(acc)(x), xs);
    }
    else
    {
      return acc;
    };
  });
  List__FoldIndexedAux$list_1_String__String_list_1_String__String = (function (f, i, acc, _arg1)
  {
    if ((_arg1.Tag == 1.000000)) 
    {
      var xs = _arg1.Item2;
      var x = _arg1.Item1;
      return List__FoldIndexedAux$list_1_String__String_list_1_String__String(f, (i + 1), f(i)(acc)(x), xs);
    }
    else
    {
      return acc;
    };
  });
  List__FoldIndexedAux$list_1_String__Tuple_2_String__String_list_1_String__Tuple_2_String__String_ = (function (f, i, acc, _arg1)
  {
    if ((_arg1.Tag == 1.000000)) 
    {
      var xs = _arg1.Item2;
      var x = _arg1.Item1;
      return List__FoldIndexedAux$list_1_String__Tuple_2_String__String_list_1_String__Tuple_2_String__String_(f, (i + 1), f(i)(acc)(x), xs);
    }
    else
    {
      return acc;
    };
  });
  List__IterateIndexed$Object_Object_ = (function (f, xs)
  {
    var _1302;
    return List__FoldIndexed$Object__Unit_Object__Unit_((function (i)
    {
      return (function (unitVar1)
      {
        return (function (x)
        {
          return f(i)(x);
        });
      });
    }), _1302, xs);
  });
  List__IterateIndexed$String_String = (function (f, xs)
  {
    var _3559;
    return List__FoldIndexed$String__Unit_String_Unit_((function (i)
    {
      return (function (unitVar1)
      {
        return (function (x)
        {
          return f(i)(x);
        });
      });
    }), _3559, xs);
  });
  List__Length$Object_Object_ = (function (xs)
  {
    return List__Fold$Object__Int32_Object__Int32((function (acc)
    {
      return (function (_arg1)
      {
        return (acc + 1);
      });
    }), 0, xs);
  });
  List__Length$String_String = (function (xs)
  {
    return List__Fold$String__Int32_String_Int32((function (acc)
    {
      return (function (_arg1)
      {
        return (acc + 1);
      });
    }), 0, xs);
  });
  List__Map$Tuple_2_String__String__String_Tuple_2_String__String__String = (function (f, xs)
  {
    return (function (_xs)
    {
      return List__Reverse$String_String(_xs);
    })(List__Fold$Tuple_2_String__String__list_1_String_Tuple_2_String__String__list_1_String_((function (acc)
    {
      return (function (x)
      {
        return (new list_1_String__ConsString(f(x), acc));
      });
    }), (new list_1_String__NilString()), xs));
  });
  List__Reverse$String_String = (function (xs)
  {
    return List__Fold$String__list_1_String_String_list_1_String_((function (acc)
    {
      return (function (x)
      {
        return (new list_1_String__ConsString(x, acc));
      });
    }), (new list_1_String__NilString()), xs);
  });
  List__ToArray$Object_Object_ = (function (xs)
  {
    var size = List__Length$Object_Object_(xs);
    var ys = Array__ZeroCreate$Object_Object_(size);
    List__IterateIndexed$Object_Object_((function (i)
    {
      return (function (x)
      {
        ys[i] = x;
        return null;
      });
    }), xs);
    return ys;
  });
  List__ToArray$String_String = (function (xs)
  {
    var size = List__Length$String_String(xs);
    var ys = Array__ZeroCreate$String_String(size);
    List__IterateIndexed$String_String((function (i)
    {
      return (function (x)
      {
        ys[i] = x;
        return null;
      });
    }), xs);
    return ys;
  });
  MapTreeModule__add$IComparable__Object_IComparable__Object_ = (function (comparer, k, v, m)
  {
    if ((m.Tag == 1.000000)) 
    {
      var k2 = m.Item1;
      var c = comparer.Compare(k, k2);
      if ((c < 0)) 
      {
        return (new MapTree_2_IComparable__Object__MapNodeIComparable__Object_(k, v, (new MapTree_2_IComparable__Object__MapEmptyIComparable__Object_()), m, 2));
      }
      else
      {
        if ((c == 0)) 
        {
          return (new MapTree_2_IComparable__Object__MapOneIComparable__Object_(k, v));
        }
        else
        {
          return (new MapTree_2_IComparable__Object__MapNodeIComparable__Object_(k, v, m, (new MapTree_2_IComparable__Object__MapEmptyIComparable__Object_()), 2));
        };
      };
    }
    else
    {
      if ((m.Tag == 2.000000)) 
      {
        var v2 = m.Item2;
        var r = m.Item4;
        var l = m.Item3;
        var _k2 = m.Item1;
        var h = m.Item5;
        var _c = comparer.Compare(k, _k2);
        if ((_c < 0)) 
        {
          return MapTreeModule__rebalance$IComparable__Object_IComparable__Object_(MapTreeModule__add$IComparable__Object_IComparable__Object_(comparer, k, v, l), _k2, v2, r);
        }
        else
        {
          if ((_c == 0)) 
          {
            return (new MapTree_2_IComparable__Object__MapNodeIComparable__Object_(k, v, l, r, h));
          }
          else
          {
            return MapTreeModule__rebalance$IComparable__Object_IComparable__Object_(l, _k2, v2, MapTreeModule__add$IComparable__Object_IComparable__Object_(comparer, k, v, r));
          };
        };
      }
      else
      {
        return (new MapTree_2_IComparable__Object__MapOneIComparable__Object_(k, v));
      };
    };
  });
  MapTreeModule__add$Int32__Object_Int32_Object_ = (function (comparer, k, v, m)
  {
    if ((m.Tag == 1.000000)) 
    {
      var k2 = m.Item1;
      var c = comparer.Compare(k, k2);
      if ((c < 0)) 
      {
        return (new MapTree_2_Int32__Object__MapNodeInt32_Object_(k, v, (new MapTree_2_Int32__Object__MapEmptyInt32_Object_()), m, 2));
      }
      else
      {
        if ((c == 0)) 
        {
          return (new MapTree_2_Int32__Object__MapOneInt32_Object_(k, v));
        }
        else
        {
          return (new MapTree_2_Int32__Object__MapNodeInt32_Object_(k, v, m, (new MapTree_2_Int32__Object__MapEmptyInt32_Object_()), 2));
        };
      };
    }
    else
    {
      if ((m.Tag == 2.000000)) 
      {
        var v2 = m.Item2;
        var r = m.Item4;
        var l = m.Item3;
        var _k2 = m.Item1;
        var h = m.Item5;
        var _c = comparer.Compare(k, _k2);
        if ((_c < 0)) 
        {
          return MapTreeModule__rebalance$Int32__Object_Int32_Object_(MapTreeModule__add$Int32__Object_Int32_Object_(comparer, k, v, l), _k2, v2, r);
        }
        else
        {
          if ((_c == 0)) 
          {
            return (new MapTree_2_Int32__Object__MapNodeInt32_Object_(k, v, l, r, h));
          }
          else
          {
            return MapTreeModule__rebalance$Int32__Object_Int32_Object_(l, _k2, v2, MapTreeModule__add$Int32__Object_Int32_Object_(comparer, k, v, r));
          };
        };
      }
      else
      {
        return (new MapTree_2_Int32__Object__MapOneInt32_Object_(k, v));
      };
    };
  });
  MapTreeModule__add$String__Int32_String_Int32 = (function (comparer, k, v, m)
  {
    if ((m.Tag == 1.000000)) 
    {
      var k2 = m.Item1;
      var c = comparer.Compare(k, k2);
      if ((c < 0)) 
      {
        return (new MapTree_2_String__Int32__MapNodeString_Int32(k, v, (new MapTree_2_String__Int32__MapEmptyString_Int32()), m, 2));
      }
      else
      {
        if ((c == 0)) 
        {
          return (new MapTree_2_String__Int32__MapOneString_Int32(k, v));
        }
        else
        {
          return (new MapTree_2_String__Int32__MapNodeString_Int32(k, v, m, (new MapTree_2_String__Int32__MapEmptyString_Int32()), 2));
        };
      };
    }
    else
    {
      if ((m.Tag == 2.000000)) 
      {
        var v2 = m.Item2;
        var r = m.Item4;
        var l = m.Item3;
        var _k2 = m.Item1;
        var h = m.Item5;
        var _c = comparer.Compare(k, _k2);
        if ((_c < 0)) 
        {
          return MapTreeModule__rebalance$String__Int32_String_Int32(MapTreeModule__add$String__Int32_String_Int32(comparer, k, v, l), _k2, v2, r);
        }
        else
        {
          if ((_c == 0)) 
          {
            return (new MapTree_2_String__Int32__MapNodeString_Int32(k, v, l, r, h));
          }
          else
          {
            return MapTreeModule__rebalance$String__Int32_String_Int32(l, _k2, v2, MapTreeModule__add$String__Int32_String_Int32(comparer, k, v, r));
          };
        };
      }
      else
      {
        return (new MapTree_2_String__Int32__MapOneString_Int32(k, v));
      };
    };
  });
  MapTreeModule__empty$String__Int32_String_Int32 = (function ()
  {
    return (new MapTree_2_String__Int32__MapEmptyString_Int32());
  });
  MapTreeModule__find$IComparable__Object_IComparable__Object_ = (function (comparer, k, m)
  {
    if ((m.Tag == 1.000000)) 
    {
      var v2 = m.Item2;
      var k2 = m.Item1;
      var c = comparer.Compare(k, k2);
      if ((c == 0)) 
      {
        return v2;
      }
      else
      {
        throw ("key not found");
        return null;
      };
    }
    else
    {
      if ((m.Tag == 2.000000)) 
      {
        var _v2 = m.Item2;
        var r = m.Item4;
        var l = m.Item3;
        var _k2 = m.Item1;
        var _c = comparer.Compare(k, _k2);
        if ((_c < 0)) 
        {
          return MapTreeModule__find$IComparable__Object_IComparable__Object_(comparer, k, l);
        }
        else
        {
          if ((_c == 0)) 
          {
            return _v2;
          }
          else
          {
            return MapTreeModule__find$IComparable__Object_IComparable__Object_(comparer, k, r);
          };
        };
      }
      else
      {
        throw ("key not found");
        return null;
      };
    };
  });
  MapTreeModule__height$IComparable__Object_IComparable__Object_ = (function (_arg1)
  {
    if ((_arg1.Tag == 1.000000)) 
    {
      return 1;
    }
    else
    {
      if ((_arg1.Tag == 2.000000)) 
      {
        var h = _arg1.Item5;
        return h;
      }
      else
      {
        return 0;
      };
    };
  });
  MapTreeModule__height$Int32__Object_Int32_Object_ = (function (_arg1)
  {
    if ((_arg1.Tag == 1.000000)) 
    {
      return 1;
    }
    else
    {
      if ((_arg1.Tag == 2.000000)) 
      {
        var h = _arg1.Item5;
        return h;
      }
      else
      {
        return 0;
      };
    };
  });
  MapTreeModule__height$String__Int32_String_Int32 = (function (_arg1)
  {
    if ((_arg1.Tag == 1.000000)) 
    {
      return 1;
    }
    else
    {
      if ((_arg1.Tag == 2.000000)) 
      {
        var h = _arg1.Item5;
        return h;
      }
      else
      {
        return 0;
      };
    };
  });
  MapTreeModule__iter$String__String_String_String = (function (f, m)
  {
    if ((m.Tag == 1.000000)) 
    {
      var v2 = m.Item2;
      var k2 = m.Item1;
      return f(k2)(v2);
    }
    else
    {
      if ((m.Tag == 2.000000)) 
      {
        var _v2 = m.Item2;
        var r = m.Item4;
        var l = m.Item3;
        var _k2 = m.Item1;
        MapTreeModule__iter$String__String_String_String(f, l);
        f(_k2)(_v2);
        return MapTreeModule__iter$String__String_String_String(f, r);
      }
      else
      {
        ;
      };
    };
  });
  MapTreeModule__mk$IComparable__Object_IComparable__Object_ = (function (l, k, v, r)
  {
    var matchValue = (new TupleMapTree_2_IComparable__Object__MapTree_2_IComparable__Object_(l, r));
    if ((matchValue.Items[0.000000].Tag == 0.000000)) 
    {
      if ((matchValue.Items[1.000000].Tag == 0.000000)) 
      {
        return (new MapTree_2_IComparable__Object__MapOneIComparable__Object_(k, v));
      }
      else
      {
        var hl = MapTreeModule__height$IComparable__Object_IComparable__Object_(l);
        var hr = MapTreeModule__height$IComparable__Object_IComparable__Object_(r);
        var _2612;
        if ((hl < hr)) 
        {
          _2612 = hr;
        }
        else
        {
          _2612 = hl;
        };
        var m = _2612;
        return (new MapTree_2_IComparable__Object__MapNodeIComparable__Object_(k, v, l, r, (m + 1)));
      };
    }
    else
    {
      var _hl = MapTreeModule__height$IComparable__Object_IComparable__Object_(l);
      var _hr = MapTreeModule__height$IComparable__Object_IComparable__Object_(r);
      var _2627;
      if ((_hl < _hr)) 
      {
        _2627 = _hr;
      }
      else
      {
        _2627 = _hl;
      };
      var _m = _2627;
      return (new MapTree_2_IComparable__Object__MapNodeIComparable__Object_(k, v, l, r, (_m + 1)));
    };
  });
  MapTreeModule__mk$Int32__Object_Int32_Object_ = (function (l, k, v, r)
  {
    var matchValue = (new TupleMapTree_2_Int32__Object__MapTree_2_Int32__Object_(l, r));
    if ((matchValue.Items[0.000000].Tag == 0.000000)) 
    {
      if ((matchValue.Items[1.000000].Tag == 0.000000)) 
      {
        return (new MapTree_2_Int32__Object__MapOneInt32_Object_(k, v));
      }
      else
      {
        var hl = MapTreeModule__height$Int32__Object_Int32_Object_(l);
        var hr = MapTreeModule__height$Int32__Object_Int32_Object_(r);
        var _2043;
        if ((hl < hr)) 
        {
          _2043 = hr;
        }
        else
        {
          _2043 = hl;
        };
        var m = _2043;
        return (new MapTree_2_Int32__Object__MapNodeInt32_Object_(k, v, l, r, (m + 1)));
      };
    }
    else
    {
      var _hl = MapTreeModule__height$Int32__Object_Int32_Object_(l);
      var _hr = MapTreeModule__height$Int32__Object_Int32_Object_(r);
      var _2058;
      if ((_hl < _hr)) 
      {
        _2058 = _hr;
      }
      else
      {
        _2058 = _hl;
      };
      var _m = _2058;
      return (new MapTree_2_Int32__Object__MapNodeInt32_Object_(k, v, l, r, (_m + 1)));
    };
  });
  MapTreeModule__mk$String__Int32_String_Int32 = (function (l, k, v, r)
  {
    var matchValue = (new TupleMapTree_2_String__Int32__MapTree_2_String__Int32_(l, r));
    if ((matchValue.Items[0.000000].Tag == 0.000000)) 
    {
      if ((matchValue.Items[1.000000].Tag == 0.000000)) 
      {
        return (new MapTree_2_String__Int32__MapOneString_Int32(k, v));
      }
      else
      {
        var hl = MapTreeModule__height$String__Int32_String_Int32(l);
        var hr = MapTreeModule__height$String__Int32_String_Int32(r);
        var _516;
        if ((hl < hr)) 
        {
          _516 = hr;
        }
        else
        {
          _516 = hl;
        };
        var m = _516;
        return (new MapTree_2_String__Int32__MapNodeString_Int32(k, v, l, r, (m + 1)));
      };
    }
    else
    {
      var _hl = MapTreeModule__height$String__Int32_String_Int32(l);
      var _hr = MapTreeModule__height$String__Int32_String_Int32(r);
      var _531;
      if ((_hl < _hr)) 
      {
        _531 = _hr;
      }
      else
      {
        _531 = _hl;
      };
      var _m = _531;
      return (new MapTree_2_String__Int32__MapNodeString_Int32(k, v, l, r, (_m + 1)));
    };
  });
  MapTreeModule__ofArray$String__Int32_String_Int32 = (function (comparer, arr)
  {
    var res = MapTreeModule__empty$String__Int32_String_Int32();
    for (var i = 0; i <= (Array__BoxedLength$(arr) - 1); i++)
    {
      var patternInput = arr[i];
      var y = patternInput.Items[1.000000];
      var x = patternInput.Items[0.000000];
      res = MapTreeModule__add$String__Int32_String_Int32(comparer, x, y, res);
      null;
    };
    return res;
  });
  MapTreeModule__rebalance$IComparable__Object_IComparable__Object_ = (function (t1, k, v, t2)
  {
    var t1h = MapTreeModule__height$IComparable__Object_IComparable__Object_(t1);
    var t2h = MapTreeModule__height$IComparable__Object_IComparable__Object_(t2);
    if ((t2h > (t1h + 2))) 
    {
      if ((t2.Tag == 2.000000)) 
      {
        var t2v = t2.Item2;
        var t2r = t2.Item4;
        var t2l = t2.Item3;
        var t2k = t2.Item1;
        if ((MapTreeModule__height$IComparable__Object_IComparable__Object_(t2l) > (t1h + 1))) 
        {
          if ((t2l.Tag == 2.000000)) 
          {
            var t2lv = t2l.Item2;
            var t2lr = t2l.Item4;
            var t2ll = t2l.Item3;
            var t2lk = t2l.Item1;
            return MapTreeModule__mk$IComparable__Object_IComparable__Object_(MapTreeModule__mk$IComparable__Object_IComparable__Object_(t1, k, v, t2ll), t2lk, t2lv, MapTreeModule__mk$IComparable__Object_IComparable__Object_(t2lr, t2k, t2v, t2r));
          }
          else
          {
            throw ("rebalance");
            return null;
          };
        }
        else
        {
          return MapTreeModule__mk$IComparable__Object_IComparable__Object_(MapTreeModule__mk$IComparable__Object_IComparable__Object_(t1, k, v, t2l), t2k, t2v, t2r);
        };
      }
      else
      {
        throw ("rebalance");
        return null;
      };
    }
    else
    {
      if ((t1h > (t2h + 2))) 
      {
        if ((t1.Tag == 2.000000)) 
        {
          var t1v = t1.Item2;
          var t1r = t1.Item4;
          var t1l = t1.Item3;
          var t1k = t1.Item1;
          if ((MapTreeModule__height$IComparable__Object_IComparable__Object_(t1r) > (t2h + 1))) 
          {
            if ((t1r.Tag == 2.000000)) 
            {
              var t1rv = t1r.Item2;
              var t1rr = t1r.Item4;
              var t1rl = t1r.Item3;
              var t1rk = t1r.Item1;
              return MapTreeModule__mk$IComparable__Object_IComparable__Object_(MapTreeModule__mk$IComparable__Object_IComparable__Object_(t1l, t1k, t1v, t1rl), t1rk, t1rv, MapTreeModule__mk$IComparable__Object_IComparable__Object_(t1rr, k, v, t2));
            }
            else
            {
              throw ("re  balance");
              return null;
            };
          }
          else
          {
            return MapTreeModule__mk$IComparable__Object_IComparable__Object_(t1l, t1k, t1v, MapTreeModule__mk$IComparable__Object_IComparable__Object_(t1r, k, v, t2));
          };
        }
        else
        {
          throw ("rebalance");
          return null;
        };
      }
      else
      {
        return MapTreeModule__mk$IComparable__Object_IComparable__Object_(t1, k, v, t2);
      };
    };
  });
  MapTreeModule__rebalance$Int32__Object_Int32_Object_ = (function (t1, k, v, t2)
  {
    var t1h = MapTreeModule__height$Int32__Object_Int32_Object_(t1);
    var t2h = MapTreeModule__height$Int32__Object_Int32_Object_(t2);
    if ((t2h > (t1h + 2))) 
    {
      if ((t2.Tag == 2.000000)) 
      {
        var t2v = t2.Item2;
        var t2r = t2.Item4;
        var t2l = t2.Item3;
        var t2k = t2.Item1;
        if ((MapTreeModule__height$Int32__Object_Int32_Object_(t2l) > (t1h + 1))) 
        {
          if ((t2l.Tag == 2.000000)) 
          {
            var t2lv = t2l.Item2;
            var t2lr = t2l.Item4;
            var t2ll = t2l.Item3;
            var t2lk = t2l.Item1;
            return MapTreeModule__mk$Int32__Object_Int32_Object_(MapTreeModule__mk$Int32__Object_Int32_Object_(t1, k, v, t2ll), t2lk, t2lv, MapTreeModule__mk$Int32__Object_Int32_Object_(t2lr, t2k, t2v, t2r));
          }
          else
          {
            throw ("rebalance");
            return null;
          };
        }
        else
        {
          return MapTreeModule__mk$Int32__Object_Int32_Object_(MapTreeModule__mk$Int32__Object_Int32_Object_(t1, k, v, t2l), t2k, t2v, t2r);
        };
      }
      else
      {
        throw ("rebalance");
        return null;
      };
    }
    else
    {
      if ((t1h > (t2h + 2))) 
      {
        if ((t1.Tag == 2.000000)) 
        {
          var t1v = t1.Item2;
          var t1r = t1.Item4;
          var t1l = t1.Item3;
          var t1k = t1.Item1;
          if ((MapTreeModule__height$Int32__Object_Int32_Object_(t1r) > (t2h + 1))) 
          {
            if ((t1r.Tag == 2.000000)) 
            {
              var t1rv = t1r.Item2;
              var t1rr = t1r.Item4;
              var t1rl = t1r.Item3;
              var t1rk = t1r.Item1;
              return MapTreeModule__mk$Int32__Object_Int32_Object_(MapTreeModule__mk$Int32__Object_Int32_Object_(t1l, t1k, t1v, t1rl), t1rk, t1rv, MapTreeModule__mk$Int32__Object_Int32_Object_(t1rr, k, v, t2));
            }
            else
            {
              throw ("re  balance");
              return null;
            };
          }
          else
          {
            return MapTreeModule__mk$Int32__Object_Int32_Object_(t1l, t1k, t1v, MapTreeModule__mk$Int32__Object_Int32_Object_(t1r, k, v, t2));
          };
        }
        else
        {
          throw ("rebalance");
          return null;
        };
      }
      else
      {
        return MapTreeModule__mk$Int32__Object_Int32_Object_(t1, k, v, t2);
      };
    };
  });
  MapTreeModule__rebalance$String__Int32_String_Int32 = (function (t1, k, v, t2)
  {
    var t1h = MapTreeModule__height$String__Int32_String_Int32(t1);
    var t2h = MapTreeModule__height$String__Int32_String_Int32(t2);
    if ((t2h > (t1h + 2))) 
    {
      if ((t2.Tag == 2.000000)) 
      {
        var t2v = t2.Item2;
        var t2r = t2.Item4;
        var t2l = t2.Item3;
        var t2k = t2.Item1;
        if ((MapTreeModule__height$String__Int32_String_Int32(t2l) > (t1h + 1))) 
        {
          if ((t2l.Tag == 2.000000)) 
          {
            var t2lv = t2l.Item2;
            var t2lr = t2l.Item4;
            var t2ll = t2l.Item3;
            var t2lk = t2l.Item1;
            return MapTreeModule__mk$String__Int32_String_Int32(MapTreeModule__mk$String__Int32_String_Int32(t1, k, v, t2ll), t2lk, t2lv, MapTreeModule__mk$String__Int32_String_Int32(t2lr, t2k, t2v, t2r));
          }
          else
          {
            throw ("rebalance");
            return null;
          };
        }
        else
        {
          return MapTreeModule__mk$String__Int32_String_Int32(MapTreeModule__mk$String__Int32_String_Int32(t1, k, v, t2l), t2k, t2v, t2r);
        };
      }
      else
      {
        throw ("rebalance");
        return null;
      };
    }
    else
    {
      if ((t1h > (t2h + 2))) 
      {
        if ((t1.Tag == 2.000000)) 
        {
          var t1v = t1.Item2;
          var t1r = t1.Item4;
          var t1l = t1.Item3;
          var t1k = t1.Item1;
          if ((MapTreeModule__height$String__Int32_String_Int32(t1r) > (t2h + 1))) 
          {
            if ((t1r.Tag == 2.000000)) 
            {
              var t1rv = t1r.Item2;
              var t1rr = t1r.Item4;
              var t1rl = t1r.Item3;
              var t1rk = t1r.Item1;
              return MapTreeModule__mk$String__Int32_String_Int32(MapTreeModule__mk$String__Int32_String_Int32(t1l, t1k, t1v, t1rl), t1rk, t1rv, MapTreeModule__mk$String__Int32_String_Int32(t1rr, k, v, t2));
            }
            else
            {
              throw ("re  balance");
              return null;
            };
          }
          else
          {
            return MapTreeModule__mk$String__Int32_String_Int32(t1l, t1k, t1v, MapTreeModule__mk$String__Int32_String_Int32(t1r, k, v, t2));
          };
        }
        else
        {
          throw ("rebalance");
          return null;
        };
      }
      else
      {
        return MapTreeModule__mk$String__Int32_String_Int32(t1, k, v, t2);
      };
    };
  });
  MapTreeModule__tryFind$IComparable__Object_IComparable__Object_ = (function (comparer, k, m)
  {
    if ((m.Tag == 1.000000)) 
    {
      var v2 = m.Item2;
      var k2 = m.Item1;
      var c = comparer.Compare(k, k2);
      if ((c == 0)) 
      {
        return {Tag: 1.000000, Value: v2};
      }
      else
      {
        return {Tag: 0.000000};
      };
    }
    else
    {
      if ((m.Tag == 2.000000)) 
      {
        var _v2 = m.Item2;
        var r = m.Item4;
        var l = m.Item3;
        var _k2 = m.Item1;
        var _c = comparer.Compare(k, _k2);
        if ((_c < 0)) 
        {
          return MapTreeModule__tryFind$IComparable__Object_IComparable__Object_(comparer, k, l);
        }
        else
        {
          if ((_c == 0)) 
          {
            return {Tag: 1.000000, Value: _v2};
          }
          else
          {
            return MapTreeModule__tryFind$IComparable__Object_IComparable__Object_(comparer, k, r);
          };
        };
      }
      else
      {
        return {Tag: 0.000000};
      };
    };
  });
  MapTreeModule__tryFind$Int32__Object_Int32_Object_ = (function (comparer, k, m)
  {
    if ((m.Tag == 1.000000)) 
    {
      var v2 = m.Item2;
      var k2 = m.Item1;
      var c = comparer.Compare(k, k2);
      if ((c == 0)) 
      {
        return {Tag: 1.000000, Value: v2};
      }
      else
      {
        return {Tag: 0.000000};
      };
    }
    else
    {
      if ((m.Tag == 2.000000)) 
      {
        var _v2 = m.Item2;
        var r = m.Item4;
        var l = m.Item3;
        var _k2 = m.Item1;
        var _c = comparer.Compare(k, _k2);
        if ((_c < 0)) 
        {
          return MapTreeModule__tryFind$Int32__Object_Int32_Object_(comparer, k, l);
        }
        else
        {
          if ((_c == 0)) 
          {
            return {Tag: 1.000000, Value: _v2};
          }
          else
          {
            return MapTreeModule__tryFind$Int32__Object_Int32_Object_(comparer, k, r);
          };
        };
      }
      else
      {
        return {Tag: 0.000000};
      };
    };
  });
  MapTree_2_IComparable__Object__MapEmptyIComparable__Object_ = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "MapEmpty";
  });
  MapTree_2_IComparable__Object__MapEmptyIComparable__Object_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  MapTree_2_IComparable__Object__MapNodeIComparable__Object_ = (function (Item1, Item2, Item3, Item4, Item5)
  {
    this.Tag = 2.000000;
    this._CaseName = "MapNode";
    this.Item1 = Item1;
    this.Item2 = Item2;
    this.Item3 = Item3;
    this.Item4 = Item4;
    this.Item5 = Item5;
  });
  MapTree_2_IComparable__Object__MapNodeIComparable__Object_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item1.CompareTo(that.Item1);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.Item2.CompareTo(that.Item2);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          var ____diff = 0.000000;
          ____diff = this.Item3.CompareTo(that.Item3);
          diff = ____diff;
          if ((diff != 0.000000)) 
          {
            return diff;
          }
          else
          {
            var _____diff = 0.000000;
            _____diff = this.Item4.CompareTo(that.Item4);
            diff = _____diff;
            if ((diff != 0.000000)) 
            {
              return diff;
            }
            else
            {
              var ______diff = 0.000000;
              ______diff = ((this.Item5 < that.Item5) ? -1.000000 : ((this.Item5 == that.Item5) ? 0.000000 : 1.000000));
              diff = ______diff;
              if ((diff != 0.000000)) 
              {
                return diff;
              }
              else
              {
                return 0.000000;
              };
            };
          };
        };
      };
    };
  });
  MapTree_2_IComparable__Object__MapOneIComparable__Object_ = (function (Item1, Item2)
  {
    this.Tag = 1.000000;
    this._CaseName = "MapOne";
    this.Item1 = Item1;
    this.Item2 = Item2;
  });
  MapTree_2_IComparable__Object__MapOneIComparable__Object_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item1.CompareTo(that.Item1);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.Item2.CompareTo(that.Item2);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  MapTree_2_Int32__Object__MapEmptyInt32_Object_ = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "MapEmpty";
  });
  MapTree_2_Int32__Object__MapEmptyInt32_Object_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  MapTree_2_Int32__Object__MapNodeInt32_Object_ = (function (Item1, Item2, Item3, Item4, Item5)
  {
    this.Tag = 2.000000;
    this._CaseName = "MapNode";
    this.Item1 = Item1;
    this.Item2 = Item2;
    this.Item3 = Item3;
    this.Item4 = Item4;
    this.Item5 = Item5;
  });
  MapTree_2_Int32__Object__MapNodeInt32_Object_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Item1 < that.Item1) ? -1.000000 : ((this.Item1 == that.Item1) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.Item2.CompareTo(that.Item2);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          var ____diff = 0.000000;
          ____diff = this.Item3.CompareTo(that.Item3);
          diff = ____diff;
          if ((diff != 0.000000)) 
          {
            return diff;
          }
          else
          {
            var _____diff = 0.000000;
            _____diff = this.Item4.CompareTo(that.Item4);
            diff = _____diff;
            if ((diff != 0.000000)) 
            {
              return diff;
            }
            else
            {
              var ______diff = 0.000000;
              ______diff = ((this.Item5 < that.Item5) ? -1.000000 : ((this.Item5 == that.Item5) ? 0.000000 : 1.000000));
              diff = ______diff;
              if ((diff != 0.000000)) 
              {
                return diff;
              }
              else
              {
                return 0.000000;
              };
            };
          };
        };
      };
    };
  });
  MapTree_2_Int32__Object__MapOneInt32_Object_ = (function (Item1, Item2)
  {
    this.Tag = 1.000000;
    this._CaseName = "MapOne";
    this.Item1 = Item1;
    this.Item2 = Item2;
  });
  MapTree_2_Int32__Object__MapOneInt32_Object_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Item1 < that.Item1) ? -1.000000 : ((this.Item1 == that.Item1) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.Item2.CompareTo(that.Item2);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  MapTree_2_String__FSharpFunc_2_String__Object__MapEmptyString_FSharpFunc_2_String__Object_ = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "MapEmpty";
  });
  MapTree_2_String__FSharpFunc_2_String__Object__MapEmptyString_FSharpFunc_2_String__Object_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  MapTree_2_String__Int32__MapEmptyString_Int32 = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "MapEmpty";
  });
  MapTree_2_String__Int32__MapEmptyString_Int32.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  MapTree_2_String__Int32__MapNodeString_Int32 = (function (Item1, Item2, Item3, Item4, Item5)
  {
    this.Tag = 2.000000;
    this._CaseName = "MapNode";
    this.Item1 = Item1;
    this.Item2 = Item2;
    this.Item3 = Item3;
    this.Item4 = Item4;
    this.Item5 = Item5;
  });
  MapTree_2_String__Int32__MapNodeString_Int32.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Item1 < that.Item1) ? -1.000000 : ((this.Item1 == that.Item1) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = ((this.Item2 < that.Item2) ? -1.000000 : ((this.Item2 == that.Item2) ? 0.000000 : 1.000000));
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          var ____diff = 0.000000;
          ____diff = this.Item3.CompareTo(that.Item3);
          diff = ____diff;
          if ((diff != 0.000000)) 
          {
            return diff;
          }
          else
          {
            var _____diff = 0.000000;
            _____diff = this.Item4.CompareTo(that.Item4);
            diff = _____diff;
            if ((diff != 0.000000)) 
            {
              return diff;
            }
            else
            {
              var ______diff = 0.000000;
              ______diff = ((this.Item5 < that.Item5) ? -1.000000 : ((this.Item5 == that.Item5) ? 0.000000 : 1.000000));
              diff = ______diff;
              if ((diff != 0.000000)) 
              {
                return diff;
              }
              else
              {
                return 0.000000;
              };
            };
          };
        };
      };
    };
  });
  MapTree_2_String__Int32__MapOneString_Int32 = (function (Item1, Item2)
  {
    this.Tag = 1.000000;
    this._CaseName = "MapOne";
    this.Item1 = Item1;
    this.Item2 = Item2;
  });
  MapTree_2_String__Int32__MapOneString_Int32.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Item1 < that.Item1) ? -1.000000 : ((this.Item1 == that.Item1) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = ((this.Item2 < that.Item2) ? -1.000000 : ((this.Item2 == that.Item2) ? 0.000000 : 1.000000));
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  MapTree_2_String__String__MapEmptyString_String = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "MapEmpty";
  });
  MapTree_2_String__String__MapEmptyString_String.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  Map__Empty$Int32__Object_Int32_Object_ = (function ()
  {
    return FSharpMap_2_Int32__Object__get_Empty$Int32_Object_();
  });
  Map__Empty$String__FSharpFunc_2_String__Object_String_FSharpFunc_2_String__Object_ = (function ()
  {
    return FSharpMap_2_String__FSharpFunc_2_String__Object__get_Empty$String_FSharpFunc_2_String__Object_();
  });
  Map__Empty$String__String_String_String = (function ()
  {
    return FSharpMap_2_String__String__get_Empty$String_String();
  });
  Map__Iterate$String__String_String_String = (function (f, m)
  {
    return FSharpMap_2_String__String__Iterate$String_String(m, f);
  });
  Map__OfArray$String__Int32_String_Int32 = (function (array)
  {
    var comparer = (new GenericComparer_1_String___ctor$String());
    var _360;
    var impl;
    impl = comparer;
    _360 = {Compare: (function (x, y)
    {
      return (function (__, x, y)
      {
        var diff = 0.000000;
        diff = ((x < y) ? -1.000000 : ((x == y) ? 0.000000 : 1.000000));
        return diff;
      })(impl, x, y);
    })};
    var _363;
    var _364;
    var _impl;
    _impl = comparer;
    _364 = {Compare: (function (x, y)
    {
      return (function (__, x, y)
      {
        var diff = 0.000000;
        diff = ((x < y) ? -1.000000 : ((x == y) ? 0.000000 : 1.000000));
        return diff;
      })(_impl, x, y);
    })};
    _363 = MapTreeModule__ofArray$String__Int32_String_Int32(_364, array);
    return (new FSharpMap_2_String__Int32___ctor$String_Int32(_360, _363));
  });
  Message___ctor$ = (function (Sender, Subject, Content)
  {
    this.Sender = Sender;
    this.Subject = Subject;
    this.Content = Content;
  });
  Message___ctor$.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Sender < that.Sender) ? -1.000000 : ((this.Sender == that.Sender) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Subject < that.Subject) ? -1.000000 : ((this.Subject == that.Subject) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = ((this.Content < that.Content) ? -1.000000 : ((this.Content == that.Content) ? 0.000000 : 1.000000));
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  Option__GetValue$Boolean_Boolean = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$CancellationToken_CancellationToken_ = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$Char_Char = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$FSharpFunc_2_Object__String_FSharpFunc_2_Object__String_ = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$FSharpFunc_2_String__Object_FSharpFunc_2_String__Object_ = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$FSharpRef_1_Boolean_FSharpRef_1_Boolean_ = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$Int32_Int32 = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$Object_Object_ = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$PropertyInfo___PropertyInfo___ = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$String_String = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$Tuple_2_String__Int32_Tuple_2_String__Int32_ = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$Tuple_2___Tuple_2___ = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$Type_1Type_1 = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$Type___Type___ = (function (option)
  {
    return option.Value;;
  });
  Option__GetValue$UnionCaseInfo___UnionCaseInfo___ = (function (option)
  {
    return option.Value;;
  });
  Option__IsSome$Int32_Int32 = (function (option)
  {
    return ((option.Tag == 1.000000) && true);
  });
  PrimitiveType__BoolType = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "BoolType";
  });
  PrimitiveType__BoolType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  PrimitiveType__CharType = (function ()
  {
    this.Tag = 7.000000;
    this._CaseName = "CharType";
  });
  PrimitiveType__CharType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  PrimitiveType__DecimalType = (function ()
  {
    this.Tag = 6.000000;
    this._CaseName = "DecimalType";
  });
  PrimitiveType__DecimalType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  PrimitiveType__FloatType = (function ()
  {
    this.Tag = 5.000000;
    this._CaseName = "FloatType";
  });
  PrimitiveType__FloatType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  PrimitiveType__HexType = (function ()
  {
    this.Tag = 4.000000;
    this._CaseName = "HexType";
  });
  PrimitiveType__HexType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  PrimitiveType__IntType = (function ()
  {
    this.Tag = 1.000000;
    this._CaseName = "IntType";
  });
  PrimitiveType__IntType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  PrimitiveType__StringType = (function ()
  {
    this.Tag = 2.000000;
    this._CaseName = "StringType";
  });
  PrimitiveType__StringType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  PrimitiveType__UIntType = (function ()
  {
    this.Tag = 3.000000;
    this._CaseName = "UIntType";
  });
  PrimitiveType__UIntType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  Program__get_ctx$ = (function ()
  {
    return Lazy_1_Object__Create$Object_((function (unitVar)
    {
      var var0 = "http://localhost:8080/";
      return (new ApiDataContext___ctor$(var0));
    }));
  });
  Program__jq$ = (function (selector)
  {
    return ((window.$)(selector));
  });
  Program__main$ = (function (unitVar0)
  {
    (function (value)
    {
      var ignored0 = value;
    })((Program__op_Dynamic$JQuery_JQuery_((function (selector)
    {
      return Program__jq$(selector);
    }), "submit").click((function (_arg1)
    {
      return Program__sendMessage$();
    }))));
    (function (value)
    {
      var ignored0 = value;
    })((Program__op_Dynamic$JQuery_JQuery_((function (selector)
    {
      return Program__jq$(selector);
    }), "content").keydown((function (keyArgs)
    {
      if (((keyArgs.keyCode) == 13)) 
      {
        Program__sendMessage$();
      }
      else
      {
        ;
      };
      return null;
    }))));
    return (function (arg00)
    {
      return Async__StartImmediate$(arg00, {Tag: 0.000000});
    })(Program__trackMessages$Unit_Unit_({Tag: 0.000000}));
  });
  Program__op_Dynamic$JQuery_JQuery_ = (function (jq, name)
  {
    return jq(("#" + name));
  });
  Program__sendMessage$ = (function (unitVar0)
  {
    return (window.alert("Not implemented"));
  });
  Program__trackMessages$Unit_Unit_ = (function (lastId)
  {
    return (function (builder_)
    {
      return AsyncBuilder__Delay$Unit_Unit_(builder_, (function (unitVar)
      {
        var _64;
        if ((lastId.Tag == 1.000000)) 
        {
          var id = Option__GetValue$String_String(lastId);
          var _70;
          var var0 = Lazy_1_Object__get_Value$Object_(Program__ctx);
          _70 = var0;
          var _var0 = _70;
          var request = (new ApiRequest___ctor$("GET", Serialization__deserialize$(t_UrlPart___, "[{\"FixedPart\":{\"Item\":\"messages\"}},{\"FixedPart\":{\"Item\":\"since\"}},{\"VariablePart\":{\"Item1\":\"id\",\"Item2\":{\"StringType\":{}}}}]")));
          var _2769;
          var copyOfStruct = id;
          _2769 = copyOfStruct.toString();
          ApiRequest__AddParameter$(request, "id", _2769);
          request;
          _64 = AsyncExtensions__Map$Object__FSharpOption_1_Tuple_2___Object__FSharpOption_1_Tuple_2___(ApiRequest__SendAndDeserialize$(request, t_FSharpOption_1_Tuple_2___, _var0), (function (t)
          {
            return t;
          }));
        }
        else
        {
          var _4543;
          var __var0 = Lazy_1_Object__get_Value$Object_(Program__ctx);
          _4543 = __var0;
          var ___var0 = _4543;
          var _request = (new ApiRequest___ctor$("GET", Serialization__deserialize$(t_UrlPart___, "[{\"FixedPart\":{\"Item\":\"messages\"}},{\"FixedPart\":{\"Item\":\"all\"}}]")));
          _request;
          _64 = AsyncExtensions__Map$Object__FSharpOption_1_Tuple_2___Object__FSharpOption_1_Tuple_2___(ApiRequest__SendAndDeserialize$(_request, t_FSharpOption_1_Tuple_2___, ___var0), (function (t)
          {
            return t;
          }));
        };
        var getMessagesAsync = _64;
        return AsyncBuilder__Bind$FSharpOption_1_Tuple_2____Unit_FSharpOption_1_Tuple_2____Unit_(builder_, getMessagesAsync, (function (_arg1)
        {
          var messages = _arg1;
          if ((messages.Tag == 1.000000)) 
          {
            var msgs = Option__GetValue$Tuple_2___Tuple_2___(messages);
            var matchValue = Array__BoxedLength$(msgs);
            if ((matchValue == 0)) 
            {
              return AsyncBuilder__ReturnFrom$Unit_Unit_(builder_, Program__trackMessages$Unit_Unit_(lastId));
            }
            else
            {
              var _4580;
              var action = (function (tupledArg)
              {
                var __arg1 = tupledArg.Items[0.000000];
                var msg = tupledArg.Items[1.000000];
                return (function (value)
                {
                  var ignored0 = value;
                })((Program__op_Dynamic$JQuery_JQuery_((function (selector)
                {
                  return Program__jq$(selector);
                }), "messages").append((("\u003cdiv class=\"alert alert-success\"\u003e" + msg.Content) + "\u003c/div\u003e"))));
              });
              _4580 = (function (array)
              {
                return Array__Iterate$Tuple_2_String__Message_Tuple_2_String__Message_(action, array);
              });
              _4580((function (array)
              {
                return Array__Reverse$Tuple_2_String__Message_Tuple_2_String__Message_(array);
              })(msgs));
              var patternInput = msgs[0];
              var nextId = patternInput.Items[0.000000];
              return AsyncBuilder__ReturnFrom$Unit_Unit_(builder_, Program__trackMessages$Unit_Unit_({Tag: 1.000000, Value: nextId}));
            };
          }
          else
          {
            return AsyncBuilder__ReturnFrom$Unit_Unit_(builder_, Program__trackMessages$Unit_Unit_(lastId));
          };
        }));
      }));
    })(Async_1_get_async$());
  });
  PropertyInfo___ctor$ = (function (name, f, getPropType)
  {
    this.name = name;
    this.f = f;
    this.getPropType = getPropType;
  });
  PropertyInfo__get_PropertyType$ = (function (__, unitVar1)
  {
    var _685;
    return __.getPropType(_685);
  });
  Replacements_1_utf8Encoding$ = (function (unitVar0)
  {
    return (new UTF8Encoding___ctor$());
  });
  Replacements__parseBool$ = (function (x)
  {
    var matchValue = Replacements__tryParseBool$(x);
    if ((matchValue.Tag == 1.000000)) 
    {
      var y = Option__GetValue$Boolean_Boolean(matchValue);
      return y;
    }
    else
    {
      throw (("Not a valid boolean value: " + x));
      return null;
    };
  });
  Replacements__parseFloat$ = (function (x)
  {
    return parseFloat(x);;
  });
  Replacements__parseInt$ = (function (x)
  {
    return parseInt(x);;
  });
  Replacements__tryParseBool$ = (function (x)
  {
    if ((x == "true")) 
    {
      return {Tag: 1.000000, Value: true};
    }
    else
    {
      if ((x == "TRUE")) 
      {
        return {Tag: 1.000000, Value: true};
      }
      else
      {
        if ((x == "True")) 
        {
          return {Tag: 1.000000, Value: true};
        }
        else
        {
          if ((x == "false")) 
          {
            return {Tag: 1.000000, Value: false};
          }
          else
          {
            if ((x == "FALSE")) 
            {
              return {Tag: 1.000000, Value: false};
            }
            else
            {
              if ((x == "False")) 
              {
                return {Tag: 1.000000, Value: false};
              }
              else
              {
                return {Tag: 0.000000};
              };
            };
          };
        };
      };
    };
  });
  Seq__Enumerator$String_String = (function (xs)
  {
    return xs.GetEnumerator();
  });
  Seq__FoldIndexed$String__Unit_String_Unit_ = (function (f, seed, xs)
  {
    return Seq__FoldIndexedAux$Unit__String_Unit__String(f, 0, seed, Seq__Enumerator$String_String(xs));
  });
  Seq__FoldIndexedAux$Unit__String_Unit__String = (function (f, i, acc, xs)
  {
    if (xs.MoveNext()) 
    {
      return Seq__FoldIndexedAux$Unit__String_Unit__String(f, (i + 1), f(i)(acc)(xs.get_Current()), xs);
    }
    else
    {
      return acc;
    };
  });
  Seq__FromFactory$String_String = (function (f)
  {
    var impl;
    impl = (new CreateEnumerable_1_String___ctor$String(f));
    return {GetEnumerator: (function (unitVar1)
    {
      return (function (__, unitVar1)
      {
        var _3012;
        return __.factory(_3012);
      })(impl, unitVar1);
    })};
  });
  Seq__IterateIndexed$String_String = (function (f, xs)
  {
    var _3035;
    return Seq__FoldIndexed$String__Unit_String_Unit_((function (i)
    {
      return (function (unitVar1)
      {
        return (function (x)
        {
          return f(i)(x);
        });
      });
    }), _3035, xs);
  });
  Seq__OfArray$String_String = (function (xs)
  {
    var _2938;
    var f = (function (i)
    {
      if ((i < Array__BoxedLength$(xs))) 
      {
        return {Tag: 1.000000, Value: (new TupleString_Int32(xs[i], (i + 1)))};
      }
      else
      {
        return {Tag: 0.000000};
      };
    });
    _2938 = (function (seed)
    {
      return Seq__Unfold$Int32__String_Int32_String(f, seed);
    });
    return _2938(0);
  });
  Seq__ToArray$String_String = (function (xs)
  {
    var ys = Array__ZeroCreate$String_String(0);
    var _3023;
    var f = (function (i)
    {
      return (function (x)
      {
        ys[i] = x;
        return null;
      });
    });
    _3023 = (function (_xs)
    {
      return Seq__IterateIndexed$String_String(f, _xs);
    });
    _3023(xs);
    return ys;
  });
  Seq__Unfold$Int32__String_Int32_String = (function (f, seed)
  {
    return Seq__FromFactory$String_String((function (unitVar0)
    {
      var impl;
      impl = (new UnfoldEnumerator_2_Int32__String___ctor$Int32_String(seed, f));
      return {get_Current: (function (unitVar1)
      {
        return (function (__, unitVar1)
        {
          return __.current;
        })(impl, unitVar1);
      }), Dispose: (function (unitVar1)
      {
        return (function (__, unitVar1)
        {
          ;
        })(impl, unitVar1);
      }), MoveNext: (function (unitVar1)
      {
        return (function (__, unitVar1)
        {
          var next = (function (_unitVar0)
          {
            var currAcc = Option__GetValue$Int32_Int32(__.acc);
            var x = __.unfold(currAcc);
            if ((x.Tag == 1.000000)) 
            {
              var value = Option__GetValue$Tuple_2_String__Int32_Tuple_2_String__Int32_(x).Items[0.000000];
              var nextAcc = Option__GetValue$Tuple_2_String__Int32_Tuple_2_String__Int32_(x).Items[1.000000];
              __.acc = {Tag: 1.000000, Value: nextAcc};
              __.current = value;
              return true;
            }
            else
            {
              __.acc = {Tag: 0.000000};
              __.current = null;
              return false;
            };
          });
          return (Option__IsSome$Int32_Int32(__.acc) && (function ()
          {
            var _2991;
            return next(_2991);
          })());
        })(impl, unitVar1);
      }), Reset: (function (unitVar1)
      {
        return (function (__, unitVar1)
        {
          __.acc = {Tag: 1.000000, Value: __.seed};
          __.current = null;
        })(impl, unitVar1);
      })};
    }));
  });
  SerializationExtensions___ArrayType___$ = (function (t)
  {
    if (Type__get_IsArray$(t)) 
    {
      return {Tag: 1.000000, Value: Type__GetElementType$(t)};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions___BoolType___$ = (function (t)
  {
    return SerializationExtensions__isType$Boolean_Boolean(t);
  });
  SerializationExtensions___DecimalType___$ = (function (t)
  {
    return SerializationExtensions__isType$Decimal_Decimal(t);
  });
  SerializationExtensions___FloatType___$ = (function (t)
  {
    return SerializationExtensions__isType$Double_Double(t);
  });
  SerializationExtensions___Int32Type___$ = (function (t)
  {
    return SerializationExtensions__isType$Int32_Int32(t);
  });
  SerializationExtensions___Int64Type___$ = (function (t)
  {
    return SerializationExtensions__isType$Int64_Int64(t);
  });
  SerializationExtensions___RecordType___$ = (function (t)
  {
    if (FSharpType__IsRecord$(t, {Tag: 0.000000})) 
    {
      return (function (arg0)
      {
        return {Tag: 1.000000, Value: arg0};
      })(FSharpType__GetRecordFields$(t, {Tag: 1.000000, Value: SerializationExtensions__accessFlags}));
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions___StringType___$ = (function (t)
  {
    return SerializationExtensions__isType$String_String(t);
  });
  SerializationExtensions___TupleType___$ = (function (t)
  {
    if (FSharpType__IsTuple$(t)) 
    {
      return (function (arg0)
      {
        return {Tag: 1.000000, Value: arg0};
      })(FSharpType__GetTupleElements$(t));
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions___UInt32Type___$ = (function (t)
  {
    return SerializationExtensions__isType$UInt32_UInt32(t);
  });
  SerializationExtensions___UInt64Type___$ = (function (t)
  {
    return SerializationExtensions__isType$UInt64_UInt64(t);
  });
  SerializationExtensions___UnionType___$ = (function (t)
  {
    if (FSharpType__IsUnion$(t, {Tag: 0.000000})) 
    {
      return (function (arg0)
      {
        return {Tag: 1.000000, Value: arg0};
      })(FSharpType__GetUnionCases$(t, {Tag: 0.000000}));
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions__get_accessFlags$ = (function ()
  {
    return (16 | 32);
  });
  SerializationExtensions__isType$Boolean_Boolean = (function (t)
  {
    if ((Type__get_FullName$(t) == Type__get_FullName$(t_Boolean_))) 
    {
      return {Tag: 1.000000, Value: (function (value)
      {
        return value;
      })};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions__isType$Decimal_Decimal = (function (t)
  {
    if ((Type__get_FullName$(t) == Type__get_FullName$(t_Decimal_))) 
    {
      return {Tag: 1.000000, Value: (function (value)
      {
        return value;
      })};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions__isType$Double_Double = (function (t)
  {
    if ((Type__get_FullName$(t) == Type__get_FullName$(t_Double_))) 
    {
      return {Tag: 1.000000, Value: (function (value)
      {
        return value;
      })};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions__isType$Int32_Int32 = (function (t)
  {
    if ((Type__get_FullName$(t) == Type__get_FullName$(t_Int32_))) 
    {
      return {Tag: 1.000000, Value: (function (value)
      {
        return value;
      })};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions__isType$Int64_Int64 = (function (t)
  {
    if ((Type__get_FullName$(t) == Type__get_FullName$(t_Int64_))) 
    {
      return {Tag: 1.000000, Value: (function (value)
      {
        return value;
      })};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions__isType$String_String = (function (t)
  {
    if ((Type__get_FullName$(t) == Type__get_FullName$(t_String_))) 
    {
      return {Tag: 1.000000, Value: (function (value)
      {
        return value;
      })};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions__isType$UInt32_UInt32 = (function (t)
  {
    if ((Type__get_FullName$(t) == Type__get_FullName$(t_UInt32_))) 
    {
      return {Tag: 1.000000, Value: (function (value)
      {
        return value;
      })};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions__isType$UInt64_UInt64 = (function (t)
  {
    if ((Type__get_FullName$(t) == Type__get_FullName$(t_UInt64_))) 
    {
      return {Tag: 1.000000, Value: (function (value)
      {
        return value;
      })};
    }
    else
    {
      return {Tag: 0.000000};
    };
  });
  SerializationExtensions__precomputeDeserializer$ = (function (t)
  {
    return Utilities__memoizeRecLazy$Type_1_FSharpFunc_2_JsonReader__Object_Type_1_FSharpFunc_2_JsonReader__Object_((function (precomputeDeserializer)
    {
      return (function (_t)
      {
        return SerializationExtensions__precomputeDeserializerAux$(precomputeDeserializer, _t);
      });
    }))(t);
  });
  SerializationExtensions__precomputeDeserializerAux$ = (function (precomputeDeserializer, t)
  {
    var activePatternResult = SerializationExtensions___RecordType___$(t);
    if ((activePatternResult.Tag == 1.000000)) 
    {
      var pis = Option__GetValue$PropertyInfo___PropertyInfo___(activePatternResult);
      var cons = FSharpValue__PreComputeRecordConstructor$(t, {Tag: 1.000000, Value: SerializationExtensions__accessFlags});
      var _355;
      var _646;
      var _647;
      var mapping = (function (i)
      {
        return (function (pi)
        {
          return (new TupleString_Int32(Type__get_Name$(pi), i));
        });
      });
      _647 = (function (array)
      {
        return Array__MapIndexed$PropertyInfo_1_Tuple_2_String__Int32_PropertyInfo_1_Tuple_2_String__Int32_(mapping, array);
      });
      _646 = _647(pis);
      _355 = (function (elements)
      {
        return Map__OfArray$String__Int32_String_Int32(elements);
      })(_646);
      var positions = _355;
      var _676;
      var _677;
      var _mapping = (function (pi)
      {
        return precomputeDeserializer(PropertyInfo__get_PropertyType$(pi));
      });
      _677 = (function (array)
      {
        return Array__Map$PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_(_mapping, array);
      });
      _676 = _677(pis);
      var readers = _676;
      return (function (jr)
      {
        var args = JsonReaderHelpers__readJsonObject$Object_Object_(positions, readers, jr);
        return cons(args);
      });
    }
    else
    {
      var _activePatternResult = SerializationExtensions___UnionType___$(t);
      if ((_activePatternResult.Tag == 1.000000)) 
      {
        var ucis = Option__GetValue$UnionCaseInfo___UnionCaseInfo___(_activePatternResult);
        var _1029;
        var _1030;
        var __mapping = (function (uci)
        {
          var _cons = FSharpValue__PreComputeUnionConstructor$(uci, {Tag: 1.000000, Value: SerializationExtensions__accessFlags});
          var _1046;
          var _1050;
          var _1051;
          var ___mapping = (function (i)
          {
            return (function (pi)
            {
              return (new TupleString_Int32(Type__get_Name$(pi), i));
            });
          });
          _1051 = (function (array)
          {
            return Array__MapIndexed$PropertyInfo_1_Tuple_2_String__Int32_PropertyInfo_1_Tuple_2_String__Int32_(___mapping, array);
          });
          _1050 = _1051(UnionCaseInfo__GetFields$(uci));
          _1046 = (function (elements)
          {
            return Map__OfArray$String__Int32_String_Int32(elements);
          })(_1050);
          var _positions = _1046;
          var _1065;
          var _1066;
          var ____mapping = (function (pi)
          {
            return precomputeDeserializer(PropertyInfo__get_PropertyType$(pi));
          });
          _1066 = (function (array)
          {
            return Array__Map$PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_PropertyInfo_1_Lazy_1_FSharpFunc_2_JsonReader__Object_(____mapping, array);
          });
          _1065 = _1066(UnionCaseInfo__GetFields$(uci));
          var _readers = _1065;
          return (new TupleFSharpFunc_2_Object____Object__FSharpMap_2_String__Int32_1_Lazy_1___(_cons, _positions, _readers));
        });
        _1030 = (function (array)
        {
          return Array__Map$UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___UnionCaseInfo_1_Tuple_3_FSharpFunc_2_Object____Object__FSharpMap_2_String__Int32__Lazy_1___(__mapping, array);
        });
        _1029 = _1030(ucis);
        var uciInfos = _1029;
        var _1108;
        var _1112;
        var _1113;
        var ___mapping = (function (i)
        {
          return (function (uci)
          {
            return (new TupleString_Int32(UnionCaseInfo__get_Name$(uci), i));
          });
        });
        _1113 = (function (array)
        {
          return Array__MapIndexed$UnionCaseInfo_1_Tuple_2_String__Int32_UnionCaseInfo_1_Tuple_2_String__Int32_(___mapping, array);
        });
        _1112 = _1113(ucis);
        _1108 = (function (elements)
        {
          return Map__OfArray$String__Int32_String_Int32(elements);
        })(_1112);
        var tagPositions = _1108;
        return (function (jr)
        {
          JsonReader__MovePast$(jr, "{");
          JsonReader__MovePast$(jr, "\"");
          var tagName = JsonReader__ReadUpToQuoteMark$(jr);
          JsonReader__MovePast$(jr, "\"");
          JsonReader__MovePast$(jr, ":");
          var tagPosition = FSharpMap_2_IComparable__Object__get_Item$IComparable__Object_(tagPositions, tagName);
          var patternInput = uciInfos[tagPosition];
          var _readers = patternInput.Items[2.000000];
          var _positions = patternInput.Items[1.000000];
          var _cons = patternInput.Items[0.000000];
          var args = JsonReaderHelpers__readJsonObject$Object_Object_(_positions, _readers, jr);
          JsonReader__MovePast$(jr, "}");
          return _cons(args);
        });
      }
      else
      {
        var __activePatternResult = SerializationExtensions___ArrayType___$(t);
        if ((__activePatternResult.Tag == 1.000000)) 
        {
          var elementType = Option__GetValue$Type_1Type_1(__activePatternResult);
          var readElement = precomputeDeserializer(elementType);
          return (function (jr)
          {
            JsonReader__MovePast$(jr, "[");
            JsonReader__MovePastWhiteSpace$(jr);
            var buildElements;
            buildElements = (function (acc)
            {
              var matchValue = JsonReader__Peek$(jr);
              if ((matchValue == "]")) 
              {
                return acc;
              }
              else
              {
                var element = Lazy_1_Object__get_Value$Object_(readElement)(jr);
                JsonReader__MovePastWhiteSpace$(jr);
                var _matchValue = JsonReader__Peek$(jr);
                if ((_matchValue == ",")) 
                {
                  JsonReader__MovePast$(jr, ",");
                }
                else
                {
                  ;
                };
                return buildElements(List__CreateCons$Object_Object_(element, acc));
              };
            });
            var xs = (function (list)
            {
              return List__ToArray$Object_Object_(list);
            })(buildElements(List__Empty$Object_Object_()));
            var ys = Array__CreateInstance$(elementType, Array__BoxedLength$(xs));
            for (var i = 0; i <= (Array__BoxedLength$(xs) - 1); i++)
            {
              ys[i] = xs[((Array__BoxedLength$(xs) - 1) - i)];
              null;
            };
            JsonReader__MovePast$(jr, "]");
            return ys;
          });
        }
        else
        {
          var ___activePatternResult = SerializationExtensions___TupleType___$(t);
          if ((___activePatternResult.Tag == 1.000000)) 
          {
            var ts = Option__GetValue$Type___Type___(___activePatternResult);
            var _cons = FSharpValue__PreComputeTupleConstructor$(t);
            var _1437;
            var _1441;
            var _1442;
            var ____mapping = (function (i)
            {
              return (function (_arg1)
              {
                return (new TupleString_Int32(("Item" + i.toString()), i));
              });
            });
            _1442 = (function (array)
            {
              return Array__MapIndexed$Type_1_Tuple_2_String__Int32_Type_1_Tuple_2_String__Int32_(____mapping, array);
            });
            _1441 = _1442(ts);
            _1437 = (function (elements)
            {
              return Map__OfArray$String__Int32_String_Int32(elements);
            })(_1441);
            var _positions = _1437;
            var _1471;
            var _1472;
            var _____mapping = precomputeDeserializer;
            _1472 = (function (array)
            {
              return Array__Map$Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_(_____mapping, array);
            });
            _1471 = _1472(ts);
            var _readers = _1471;
            return (function (jr)
            {
              var args = JsonReaderHelpers__readJsonObject$Object_Object_(_positions, _readers, jr);
              return _cons(args);
            });
          }
          else
          {
            var ____activePatternResult = SerializationExtensions___StringType___$(t);
            if ((____activePatternResult.Tag == 1.000000)) 
            {
              var extract = Option__GetValue$FSharpFunc_2_Object__String_FSharpFunc_2_Object__String_(____activePatternResult);
              return (function (jr)
              {
                JsonReader__MovePast$(jr, "\"");
                var value = JsonReader__ReadUpToQuoteMark$(jr);
                JsonReader__MovePast$(jr, "\"");
                return value;
              });
            }
            else
            {
              var _____activePatternResult = SerializationExtensions___Int32Type___$(t);
              if ((_____activePatternResult.Tag == 1.000000)) 
              {
                return (function (jr)
                {
                  return JsonReaderHelpers__readValue$Int32_Int32((function (arg00)
                  {
                    return Replacements__parseInt$(arg00);
                  }), jr);
                });
              }
              else
              {
                var ______activePatternResult = SerializationExtensions___Int64Type___$(t);
                if ((______activePatternResult.Tag == 1.000000)) 
                {
                  return (function (jr)
                  {
                    return JsonReaderHelpers__readValue$Int64_Int64((function (arg00)
                    {
                      return Replacements__parseInt$(arg00);
                    }), jr);
                  });
                }
                else
                {
                  var _______activePatternResult = SerializationExtensions___UInt32Type___$(t);
                  if ((_______activePatternResult.Tag == 1.000000)) 
                  {
                    return (function (jr)
                    {
                      return JsonReaderHelpers__readValue$UInt32_UInt32((function (arg00)
                      {
                        return Replacements__parseInt$(arg00);
                      }), jr);
                    });
                  }
                  else
                  {
                    var ________activePatternResult = SerializationExtensions___UInt64Type___$(t);
                    if ((________activePatternResult.Tag == 1.000000)) 
                    {
                      return (function (jr)
                      {
                        return JsonReaderHelpers__readValue$Int64_Int64((function (arg00)
                        {
                          return Replacements__parseInt$(arg00);
                        }), jr);
                      });
                    }
                    else
                    {
                      var _________activePatternResult = SerializationExtensions___FloatType___$(t);
                      if ((_________activePatternResult.Tag == 1.000000)) 
                      {
                        return (function (jr)
                        {
                          return JsonReaderHelpers__readValue$Double_Double((function (arg00)
                          {
                            return Replacements__parseFloat$(arg00);
                          }), jr);
                        });
                      }
                      else
                      {
                        var __________activePatternResult = SerializationExtensions___DecimalType___$(t);
                        if ((__________activePatternResult.Tag == 1.000000)) 
                        {
                          return (function (jr)
                          {
                            return JsonReaderHelpers__readValue$Decimal_Decimal((function (arg00)
                            {
                              return Replacements__parseFloat$(arg00);
                            }), jr);
                          });
                        }
                        else
                        {
                          var ___________activePatternResult = SerializationExtensions___BoolType___$(t);
                          if ((___________activePatternResult.Tag == 1.000000)) 
                          {
                            return (function (jr)
                            {
                              return JsonReaderHelpers__readValue$Boolean_Boolean((function (arg00)
                              {
                                return Replacements__parseBool$(arg00);
                              }), jr);
                            });
                          }
                          else
                          {
                            throw (("Cannot serialize type: " + Type__get_Name$(t)));
                            return null;
                          };
                        };
                      };
                    };
                  };
                };
              };
            };
          };
        };
      };
    };
  });
  SerializationExtensions__precomputeTypeFromJson$ = (function (t)
  {
    var deserialize = SerializationExtensions__precomputeDeserializer$(t);
    return (function (json)
    {
      var reader = (new JsonReader___ctor$(json));
      return deserialize(reader);
    });
  });
  Serialization__deserialize$ = (function (t, obj)
  {
    return Serialization__getDeserializer$(t)(obj);
  });
  Serialization__getDeserializer$ = (function (t)
  {
    var matchValue = FSharpMap_2_IComparable__Object__TryFind$IComparable__Object_(Serialization__deserializers, Type__get_FullName$(t));
    if ((matchValue.Tag == 0.000000)) 
    {
      var deserialize = SerializationExtensions__precomputeTypeFromJson$(t);
      Serialization__deserializers = FSharpMap_2_IComparable__Object__Add$IComparable__Object_(Serialization__deserializers, Type__get_FullName$(t), deserialize);
      return deserialize;
    }
    else
    {
      var _deserialize = Option__GetValue$FSharpFunc_2_String__Object_FSharpFunc_2_String__Object_(matchValue);
      return _deserialize;
    };
  });
  Serialization__get_deserializers$ = (function ()
  {
    return Map__Empty$String__FSharpFunc_2_String__Object_String_FSharpFunc_2_String__Object_();
  });
  SetTreeModule__SetNode$Char_Char = (function (x, l, r, h)
  {
    return (new SetTree_1_Char__SetNodeChar(x, l, r, h));
  });
  SetTreeModule__SetOne$Char_Char = (function (n)
  {
    return (new SetTree_1_Char__SetOneChar(n));
  });
  SetTreeModule__add$Char_Char = (function (comparer, k, t)
  {
    if ((t.Tag == 2.000000)) 
    {
      var k2 = t.Item;
      var c = comparer.Compare(k, k2);
      if ((c < 0)) 
      {
        return SetTreeModule__SetNode$Char_Char(k, (new SetTree_1_Char__SetEmptyChar()), t, 2);
      }
      else
      {
        if ((c == 0)) 
        {
          return t;
        }
        else
        {
          return SetTreeModule__SetNode$Char_Char(k, t, (new SetTree_1_Char__SetEmptyChar()), 2);
        };
      };
    }
    else
    {
      if ((t.Tag == 0.000000)) 
      {
        return SetTreeModule__SetOne$Char_Char(k);
      }
      else
      {
        var r = t.Item3;
        var l = t.Item2;
        var _k2 = t.Item1;
        var _c = comparer.Compare(k, _k2);
        if ((_c < 0)) 
        {
          return SetTreeModule__rebalance$Char_Char(SetTreeModule__add$Char_Char(comparer, k, l), _k2, r);
        }
        else
        {
          if ((_c == 0)) 
          {
            return t;
          }
          else
          {
            return SetTreeModule__rebalance$Char_Char(l, _k2, SetTreeModule__add$Char_Char(comparer, k, r));
          };
        };
      };
    };
  });
  SetTreeModule__get_tolerance$ = (function ()
  {
    return 2;
  });
  SetTreeModule__height$Char_Char = (function (t)
  {
    if ((t.Tag == 2.000000)) 
    {
      return 1;
    }
    else
    {
      if ((t.Tag == 1.000000)) 
      {
        var h = t.Item4;
        return h;
      }
      else
      {
        return 0;
      };
    };
  });
  SetTreeModule__mem$Char_Char = (function (comparer, k, t)
  {
    if ((t.Tag == 2.000000)) 
    {
      var k2 = t.Item;
      return (comparer.Compare(k, k2) == 0);
    }
    else
    {
      if ((t.Tag == 0.000000)) 
      {
        return false;
      }
      else
      {
        var r = t.Item3;
        var l = t.Item2;
        var _k2 = t.Item1;
        var c = comparer.Compare(k, _k2);
        if ((c < 0)) 
        {
          return SetTreeModule__mem$Char_Char(comparer, k, l);
        }
        else
        {
          return ((c == 0) || SetTreeModule__mem$Char_Char(comparer, k, r));
        };
      };
    };
  });
  SetTreeModule__mk$Char_Char = (function (l, k, r)
  {
    var matchValue = (new TupleSetTree_1_Char__SetTree_1_Char_(l, r));
    if ((matchValue.Items[0.000000].Tag == 0.000000)) 
    {
      if ((matchValue.Items[1.000000].Tag == 0.000000)) 
      {
        return SetTreeModule__SetOne$Char_Char(k);
      }
      else
      {
        var hl = SetTreeModule__height$Char_Char(l);
        var hr = SetTreeModule__height$Char_Char(r);
        var _2323;
        if ((hl < hr)) 
        {
          _2323 = hr;
        }
        else
        {
          _2323 = hl;
        };
        var m = _2323;
        return SetTreeModule__SetNode$Char_Char(k, l, r, (m + 1));
      };
    }
    else
    {
      var _hl = SetTreeModule__height$Char_Char(l);
      var _hr = SetTreeModule__height$Char_Char(r);
      var _2337;
      if ((_hl < _hr)) 
      {
        _2337 = _hr;
      }
      else
      {
        _2337 = _hl;
      };
      var _m = _2337;
      return SetTreeModule__SetNode$Char_Char(k, l, r, (_m + 1));
    };
  });
  SetTreeModule__ofArray$Char_Char = (function (comparer, l)
  {
    return Array__Fold$Char__SetTree_1_Char_Char_SetTree_1_Char_((function (acc)
    {
      return (function (k)
      {
        return SetTreeModule__add$Char_Char(comparer, k, acc);
      });
    }), (new SetTree_1_Char__SetEmptyChar()), l);
  });
  SetTreeModule__rebalance$Char_Char = (function (t1, k, t2)
  {
    var t1h = SetTreeModule__height$Char_Char(t1);
    var t2h = SetTreeModule__height$Char_Char(t2);
    if ((t2h > (t1h + SetTreeModule__tolerance))) 
    {
      if ((t2.Tag == 1.000000)) 
      {
        var t2r = t2.Item3;
        var t2l = t2.Item2;
        var t2k = t2.Item1;
        if ((SetTreeModule__height$Char_Char(t2l) > (t1h + 1))) 
        {
          if ((t2l.Tag == 1.000000)) 
          {
            var t2lr = t2l.Item3;
            var t2ll = t2l.Item2;
            var t2lk = t2l.Item1;
            return SetTreeModule__mk$Char_Char(SetTreeModule__mk$Char_Char(t1, k, t2ll), t2lk, SetTreeModule__mk$Char_Char(t2lr, t2k, t2r));
          }
          else
          {
            throw ("rebalance");
            return null;
          };
        }
        else
        {
          return SetTreeModule__mk$Char_Char(SetTreeModule__mk$Char_Char(t1, k, t2l), t2k, t2r);
        };
      }
      else
      {
        throw ("rebalance");
        return null;
      };
    }
    else
    {
      if ((t1h > (t2h + SetTreeModule__tolerance))) 
      {
        if ((t1.Tag == 1.000000)) 
        {
          var t1r = t1.Item3;
          var t1l = t1.Item2;
          var t1k = t1.Item1;
          if ((SetTreeModule__height$Char_Char(t1r) > (t2h + 1))) 
          {
            if ((t1r.Tag == 1.000000)) 
            {
              var t1rr = t1r.Item3;
              var t1rl = t1r.Item2;
              var t1rk = t1r.Item1;
              return SetTreeModule__mk$Char_Char(SetTreeModule__mk$Char_Char(t1l, t1k, t1rl), t1rk, SetTreeModule__mk$Char_Char(t1rr, k, t2));
            }
            else
            {
              throw ("rebalance");
              return null;
            };
          }
          else
          {
            return SetTreeModule__mk$Char_Char(t1l, t1k, SetTreeModule__mk$Char_Char(t1r, k, t2));
          };
        }
        else
        {
          throw ("rebalance");
          return null;
        };
      }
      else
      {
        return SetTreeModule__mk$Char_Char(t1, k, t2);
      };
    };
  });
  SetTree_1_Char__SetEmptyChar = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "SetEmpty";
  });
  SetTree_1_Char__SetEmptyChar.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  SetTree_1_Char__SetNodeChar = (function (Item1, Item2, Item3, Item4)
  {
    this.Tag = 1.000000;
    this._CaseName = "SetNode";
    this.Item1 = Item1;
    this.Item2 = Item2;
    this.Item3 = Item3;
    this.Item4 = Item4;
  });
  SetTree_1_Char__SetNodeChar.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Item1 < that.Item1) ? -1.000000 : ((this.Item1 == that.Item1) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.Item2.CompareTo(that.Item2);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          var ____diff = 0.000000;
          ____diff = this.Item3.CompareTo(that.Item3);
          diff = ____diff;
          if ((diff != 0.000000)) 
          {
            return diff;
          }
          else
          {
            var _____diff = 0.000000;
            _____diff = ((this.Item4 < that.Item4) ? -1.000000 : ((this.Item4 == that.Item4) ? 0.000000 : 1.000000));
            diff = _____diff;
            if ((diff != 0.000000)) 
            {
              return diff;
            }
            else
            {
              return 0.000000;
            };
          };
        };
      };
    };
  });
  SetTree_1_Char__SetOneChar = (function (Item)
  {
    this.Tag = 2.000000;
    this._CaseName = "SetOne";
    this.Item = Item;
  });
  SetTree_1_Char__SetOneChar.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Item < that.Item) ? -1.000000 : ((this.Item == that.Item) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  Set_1_Char__Contains$Char = (function (s, x)
  {
    return SetTreeModule__mem$Char_Char(Set_1_Char__get_Comparer$Char(s), x, Set_1_Char__get_Tree$Char(s));
  });
  Set_1_Char__FromArray$Char = (function (arr)
  {
    var comparer = (new GenericComparer_1_Char___ctor$Char());
    var _2195;
    var impl;
    impl = comparer;
    _2195 = {Compare: (function (x, y)
    {
      return (function (__, x, y)
      {
        var diff = 0.000000;
        diff = ((x < y) ? -1.000000 : ((x == y) ? 0.000000 : 1.000000));
        return diff;
      })(impl, x, y);
    })};
    var _2198;
    var _2199;
    var _impl;
    _impl = comparer;
    _2199 = {Compare: (function (x, y)
    {
      return (function (__, x, y)
      {
        var diff = 0.000000;
        diff = ((x < y) ? -1.000000 : ((x == y) ? 0.000000 : 1.000000));
        return diff;
      })(_impl, x, y);
    })};
    _2198 = SetTreeModule__ofArray$Char_Char(_2199, arr);
    return (new Set_1_Char___ctor$Char(_2195, _2198));
  });
  Set_1_Char___ctor$Char = (function (comparer, tree)
  {
    this.comparer_479 = comparer;
    this.tree_483 = tree;
    this.serializedData = null;
  });
  Set_1_Char__get_Comparer$Char = (function (set, unitVar1)
  {
    return set.comparer_479;
  });
  Set_1_Char__get_Tree$Char = (function (set, unitVar1)
  {
    return set.tree_483;
  });
  Set__Contains$Char_Char = (function (x, s)
  {
    return Set_1_Char__Contains$Char(s, x);
  });
  Set__OfArray$Char_Char = (function (l)
  {
    return Set_1_Char__FromArray$Char(l);
  });
  Stream__AsyncRead$ = (function (stream, count)
  {
    return (function (builder_)
    {
      return AsyncBuilder__Delay$Byte___Byte___(builder_, (function (unitVar)
      {
        var start = stream.nextIndex;
        stream.nextIndex = (stream.nextIndex + count);
        return AsyncBuilder__Return$Byte___Byte___(builder_, Array__GetSubArray$Byte_Byte(stream.contents, start, count));
      }));
    })(Async_1_get_async$());
  });
  Stream__AsyncWrite$ = (function (__, buffer, offset, count)
  {
    return (function (builder_)
    {
      return AsyncBuilder__Delay$Unit_Unit_(builder_, (function (unitVar)
      {
        var _3235;
        if ((offset.Tag == 1.000000)) 
        {
          var v = Option__GetValue$Int32_Int32(offset);
          _3235 = v;
        }
        else
        {
          _3235 = 0;
        };
        var _offset = _3235;
        var _3241;
        if ((count.Tag == 1.000000)) 
        {
          var v = Option__GetValue$Int32_Int32(count);
          _3241 = v;
        }
        else
        {
          _3241 = Array__BoxedLength$(buffer);
        };
        var _count = _3241;
        var extra = Array__GetSubArray$Byte_Byte(buffer, _offset, _count);
        __.contents = Array__Append$Byte_Byte(__.contents, extra);
        return AsyncBuilder__Zero$(builder_);
      }));
    })(Async_1_get_async$());
  });
  Stream___ctor$ = (function (initalContents)
  {
    this.contents = initalContents;
    this.nextIndex = 0;
  });
  Stream__get_Contents$ = (function (__, unitVar1)
  {
    return __.contents;
  });
  String_1_CharAt$ = (function (s, length)
  {
    return s.charAt(length);;
  });
  String_1_Join$ = (function (separator, s)
  {
    return s.join(separator);;
  });
  String_1_Length$ = (function (s)
  {
    return s.length;;
  });
  String_1_Substring$ = (function (s, offset, length)
  {
    return s.substring(offset, offset + length);;
  });
  TupleFSharpFunc_2_Object____Object__FSharpMap_2_String__Int32_1_Lazy_1___ = (function (Item0, Item1, Item2)
  {
    this.Items = [Item0, Item1, Item2];
    this.Items = [Item0, Item1, Item2];
    this.Items = [Item0, Item1, Item2];
  });
  TupleFSharpFunc_2_Object____Object__FSharpMap_2_String__Int32_1_Lazy_1___.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Items[0.000000].CompareTo(that.Items[0.000000]);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Items[1.000000].CompareTo(that.Items[1.000000]);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        var i = 0.000000;
        while (((___diff == 0.000000) && ((i < this.Items[2.000000].length) && (i < that.Items[2.000000].length))))
        {
          ___diff = this.Items[2.000000][i].CompareTo(that.Items[2.000000][i]);
          i = (i + 1.000000);
        };
        ___diff = ((___diff == 0.000000) ? (this.Items[2.000000].length - that.Items[2.000000].length) : ___diff);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  TupleFSharpFunc_2_WebResponse__Unit__FSharpFunc_2_String__Unit__FSharpFunc_2_String__Unit_ = (function (Item0, Item1, Item2)
  {
    this.Items = [Item0, Item1, Item2];
    this.Items = [Item0, Item1, Item2];
    this.Items = [Item0, Item1, Item2];
  });
  TupleFSharpFunc_2_WebResponse__Unit__FSharpFunc_2_String__Unit__FSharpFunc_2_String__Unit_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Items[0.000000].CompareTo(that.Items[0.000000]);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Items[1.000000].CompareTo(that.Items[1.000000]);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.Items[2.000000].CompareTo(that.Items[2.000000]);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  TupleMapTree_2_IComparable__Object__MapTree_2_IComparable__Object_ = (function (Item0, Item1)
  {
    this.Items = [Item0, Item1];
    this.Items = [Item0, Item1];
  });
  TupleMapTree_2_IComparable__Object__MapTree_2_IComparable__Object_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Items[0.000000].CompareTo(that.Items[0.000000]);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Items[1.000000].CompareTo(that.Items[1.000000]);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  TupleMapTree_2_Int32__Object__MapTree_2_Int32__Object_ = (function (Item0, Item1)
  {
    this.Items = [Item0, Item1];
    this.Items = [Item0, Item1];
  });
  TupleMapTree_2_Int32__Object__MapTree_2_Int32__Object_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Items[0.000000].CompareTo(that.Items[0.000000]);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Items[1.000000].CompareTo(that.Items[1.000000]);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  TupleMapTree_2_String__Int32__MapTree_2_String__Int32_ = (function (Item0, Item1)
  {
    this.Items = [Item0, Item1];
    this.Items = [Item0, Item1];
  });
  TupleMapTree_2_String__Int32__MapTree_2_String__Int32_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Items[0.000000].CompareTo(that.Items[0.000000]);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Items[1.000000].CompareTo(that.Items[1.000000]);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  TupleSetTree_1_Char__SetTree_1_Char_ = (function (Item0, Item1)
  {
    this.Items = [Item0, Item1];
    this.Items = [Item0, Item1];
  });
  TupleSetTree_1_Char__SetTree_1_Char_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = this.Items[0.000000].CompareTo(that.Items[0.000000]);
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Items[1.000000].CompareTo(that.Items[1.000000]);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  TupleString_Int32 = (function (Item0, Item1)
  {
    this.Items = [Item0, Item1];
    this.Items = [Item0, Item1];
  });
  TupleString_Int32.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Items[0.000000] < that.Items[0.000000]) ? -1.000000 : ((this.Items[0.000000] == that.Items[0.000000]) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Items[1.000000] < that.Items[1.000000]) ? -1.000000 : ((this.Items[1.000000] == that.Items[1.000000]) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  TupleString_Message_ = (function (Item0, Item1)
  {
    this.Items = [Item0, Item1];
    this.Items = [Item0, Item1];
  });
  TupleString_Message_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Items[0.000000] < that.Items[0.000000]) ? -1.000000 : ((this.Items[0.000000] == that.Items[0.000000]) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Items[1.000000].CompareTo(that.Items[1.000000]);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  TupleString_String = (function (Item0, Item1)
  {
    this.Items = [Item0, Item1];
    this.Items = [Item0, Item1];
  });
  TupleString_String.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Items[0.000000] < that.Items[0.000000]) ? -1.000000 : ((this.Items[0.000000] == that.Items[0.000000]) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Items[1.000000] < that.Items[1.000000]) ? -1.000000 : ((this.Items[1.000000] == that.Items[1.000000]) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  TypeKind__ArrayType = (function (Item)
  {
    this.Tag = 4.000000;
    this._CaseName = "ArrayType";
    this.Item = Item;
  });
  TypeKind__ArrayType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item.CompareTo(that.Item);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  TypeKind__ClassType = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "ClassType";
  });
  TypeKind__ClassType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  TypeKind__RecordType = (function (Item1, Item2)
  {
    this.Tag = 1.000000;
    this._CaseName = "RecordType";
    this.Item1 = Item1;
    this.Item2 = Item2;
  });
  TypeKind__RecordType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item1.CompareTo(that.Item1);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        var i = 0.000000;
        while (((___diff == 0.000000) && ((i < this.Item2.length) && (i < that.Item2.length))))
        {
          ___diff = this.Item2[i].CompareTo(that.Item2[i]);
          i = (i + 1.000000);
        };
        ___diff = ((___diff == 0.000000) ? (this.Item2.length - that.Item2.length) : ___diff);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  TypeKind__TupleType = (function (Item1, Item2)
  {
    this.Tag = 3.000000;
    this._CaseName = "TupleType";
    this.Item1 = Item1;
    this.Item2 = Item2;
  });
  TypeKind__TupleType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item1.CompareTo(that.Item1);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        var i = 0.000000;
        while (((___diff == 0.000000) && ((i < this.Item2.length) && (i < that.Item2.length))))
        {
          ___diff = this.Item2[i].CompareTo(that.Item2[i]);
          i = (i + 1.000000);
        };
        ___diff = ((___diff == 0.000000) ? (this.Item2.length - that.Item2.length) : ___diff);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  TypeKind__UnionType = (function (Item)
  {
    this.Tag = 2.000000;
    this._CaseName = "UnionType";
    this.Item = Item;
  });
  TypeKind__UnionType.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      var i = 0.000000;
      while (((__diff == 0.000000) && ((i < this.Item.length) && (i < that.Item.length))))
      {
        __diff = this.Item[i].CompareTo(that.Item[i]);
        i = (i + 1.000000);
      };
      __diff = ((__diff == 0.000000) ? (this.Item.length - that.Item.length) : __diff);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  Type__GetElementType$ = (function (__, unitVar1)
  {
    var matchValue = __.kind;
    if ((matchValue.Tag == 4.000000)) 
    {
      var t = matchValue.Item;
      return t;
    }
    else
    {
      throw ("Not an array type.");
      return null;
    };
  });
  Type___ctor$ = (function (name, fullName, typeArgs, kind)
  {
    this.name = name;
    this.fullName = fullName;
    this.typeArgs = typeArgs;
    this.kind = kind;
  });
  Type__get_FullName$ = (function (__, unitVar1)
  {
    return __.fullName;
  });
  Type__get_IsArray$ = (function (__, unitVar1)
  {
    var matchValue = __.kind;
    return ((matchValue.Tag == 4.000000) && true);
  });
  Type__get_Kind$ = (function (__, unitVar1)
  {
    return __.kind;
  });
  Type__get_Name$ = (function (__, unitVar1)
  {
    return __.name;
  });
  UTF8Encoding__GetBytes$ = (function (__, text)
  {
    var str = text;
    var byteArray = [];
    for (var i = 0; i < str.length; i++)
        if (str.charCodeAt(i) <= 0x7F)
            byteArray.push(str.charCodeAt(i));
        else {
            var h = encodeURIComponent(str.charAt(i)).substr(1).split('%');
            for (var j = 0; j < h.length; j++)
                byteArray.push(parseInt(h[j], 16));
        }
    return byteArray;;
  });
  UTF8Encoding__GetString$ = (function (__, bytes)
  {
    var byteArray = bytes;
    var str = '';
    for (var i = 0; i < byteArray.length; i++)
        str +=  byteArray[i] <= 0x7F?
                byteArray[i] === 0x25 ? "%25" : // %
                String.fromCharCode(byteArray[i]) :
                "%" + byteArray[i].toString(16).toUpperCase();
    return decodeURIComponent(str);;
  });
  UTF8Encoding___ctor$ = (function (unitVar0)
  {
    ;
  });
  UnfoldEnumerator_2_Int32__String___ctor$Int32_String = (function (seed, unfold)
  {
    this.seed = seed;
    this.unfold = unfold;
    this.acc = {Tag: 1.000000, Value: this.seed};
    this.current = null;
  });
  UnionCaseInfo__Construct$ = (function (__, args)
  {
    return __.cons(args);
  });
  UnionCaseInfo__GetFields$ = (function (__, unitVar1)
  {
    return __.fields;
  });
  UnionCaseInfo___ctor$ = (function (name, tag, cons, fields)
  {
    this.name = name;
    this.tag = tag;
    this.cons = cons;
    this.fields = fields;
  });
  UnionCaseInfo__get_Name$ = (function (__, unitVar1)
  {
    return __.name;
  });
  UrlPart__FixedPart = (function (Item)
  {
    this.Tag = 0.000000;
    this._CaseName = "FixedPart";
    this.Item = Item;
  });
  UrlPart__FixedPart.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Item < that.Item) ? -1.000000 : ((this.Item == that.Item) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        return 0.000000;
      };
    };
  });
  UrlPart__VariablePart = (function (Item1, Item2)
  {
    this.Tag = 1.000000;
    this._CaseName = "VariablePart";
    this.Item1 = Item1;
    this.Item2 = Item2;
  });
  UrlPart__VariablePart.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Item1 < that.Item1) ? -1.000000 : ((this.Item1 == that.Item1) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.Item2.CompareTo(that.Item2);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  Utilities__memoizeRec$Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_ = (function (f)
  {
    var cache = ConcurrentDictionary_2_Object__Object__Create$Object__Object_();
    var getCached;
    getCached = (function (x)
    {
      return ConcurrentDictionary_2_Object__Object__GetOrAdd$Object__Object_(cache, x, (function (_x)
      {
        return f(getCached)(_x);
      }));
    });
    return (function (x)
    {
      return getCached(x);
    });
  });
  Utilities__memoizeRecLazy$Type_1_FSharpFunc_2_JsonReader__Object_Type_1_FSharpFunc_2_JsonReader__Object_ = (function (f)
  {
    var getCached = Utilities__memoizeRec$Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_Type_1_Lazy_1_FSharpFunc_2_JsonReader__Object_((function (g)
    {
      return (function (x)
      {
        return Lazy_1_Object__Create$Object_((function (unitVar)
        {
          return f(g)(x);
        }));
      });
    }));
    return (function (x)
    {
      return Lazy_1_Object__get_Value$Object_(getCached(x));
    });
  });
  WebHeaderCollection__Add$ = (function (__, key, value)
  {
    __.headers = List__CreateCons$Tuple_2_String__String_Tuple_2_String__String_((new TupleString_String(key, value)), __.headers);
  });
  WebHeaderCollection___ctor$ = (function (unitVar0)
  {
    this.headers = List__Empty$Tuple_2_String__String_Tuple_2_String__String_();
  });
  WebHeaderCollection__get_Keys$ = (function (__, unitVar1)
  {
    var _3585;
    var _3586;
    var mapping = (function (tuple)
    {
      return tuple.Items[0.000000];
    });
    _3586 = (function (list)
    {
      return List__Map$Tuple_2_String__String__String_Tuple_2_String__String__String(mapping, list);
    });
    _3585 = _3586(__.headers);
    return (function (list)
    {
      return List__ToArray$String_String(list);
    })(_3585);
  });
  WebHeaderCollection__get_Values$ = (function (__, unitVar1)
  {
    var _3678;
    var _3679;
    var mapping = (function (tuple)
    {
      return tuple.Items[1.000000];
    });
    _3679 = (function (list)
    {
      return List__Map$Tuple_2_String__String__String_Tuple_2_String__String__String(mapping, list);
    });
    _3678 = _3679(__.headers);
    return (function (list)
    {
      return List__ToArray$String_String(list);
    })(_3678);
  });
  WebRequest__AsyncGetResponse$ = (function (req, unitVar1)
  {
    return Async__FromContinuations$WebResponse_WebResponse_((function (tupledArg)
    {
      var onSuccess = tupledArg.Items[0.000000];
      var onError = tupledArg.Items[1.000000];
      var _arg1 = tupledArg.Items[2.000000];
      var matchValue = _arg1;
      var onReceived = (function (data)
      {
        var bytes = UTF8Encoding__GetBytes$(Replacements_1_utf8Encoding$(), data);
        return onSuccess((new WebResponse___ctor$(bytes)));
      });
      var onErrorReceived = (function (unitVar0)
      {
        return onError(null);
      });
      var _3486;
      if ((WebRequest__get_Method$(req) == "GET")) 
      {
        _3486 = null;
      }
      else
      {
        _3486 = UTF8Encoding__GetString$(Replacements_1_utf8Encoding$(), Stream__get_Contents$(req.requestStream));
      };
      var body = _3486;
      return Web__sendRequest$Unit_Unit_(WebRequest__get_Method$(req), req.url, WebHeaderCollection__get_Keys$(WebRequest__get_Headers$(req)), WebHeaderCollection__get_Values$(WebRequest__get_Headers$(req)), body, onReceived, onErrorReceived);
    }));
  });
  WebRequest__Create$ = (function (uri)
  {
    return (new WebRequest___ctor$(uri));
  });
  WebRequest__GetRequestStream$ = (function (__, unitVar1)
  {
    return __.requestStream;
  });
  WebRequest___ctor$ = (function (url)
  {
    this.url = url;
    this.requestStream = (new Stream___ctor$([]));
    this.Headers_ = (new WebHeaderCollection___ctor$());
    this.Method_ = "GET";
  });
  WebRequest__get_Headers$ = (function (__, unitVar1)
  {
    return __.Headers_;
  });
  WebRequest__get_Method$ = (function (__, unitVar1)
  {
    return __.Method_;
  });
  WebRequest__set_Method$ = (function (__, v)
  {
    __.Method_ = v;
  });
  WebResponse__GetResponseStream$ = (function (__, unitVar1)
  {
    return (new Stream___ctor$(__.contents));
  });
  WebResponse___ctor$ = (function (contents)
  {
    this.contents = contents;
  });
  WebResponse__get_ContentLength$ = (function (__, unitVar1)
  {
    return Array__BoxedLength$(__.contents);
  });
  Web__sendRequest$Unit_Unit_ = (function (meth, url, headerKeys, headerValues, body, onSuccess, onError)
  {
    
    var _method = meth, 
        _url = url, 
        _headerKeys = headerKeys, 
        _headerValues = headerValues,
        _body = body, 
        _onSuccess = onSuccess, 
        _onError = onError;

    if (window.XDomainRequest) {
        var req = new XDomainRequest();
        req.onload = function() { _onSuccess(req.responseText); };
        req.onerror = _onError;
        req.ontimeout = _onError;
        req.timeout = 10000;
        req.open(_method, _url);
        if(_body) {
            req.send(_body);
        } else {
            req.send();
        }
    }
    else {
        var req;

        if (window.XMLHttpRequest)
          req = new XMLHttpRequest();
        else
          req = new ActiveXObject("Microsoft.XMLHTTP");

        req.onreadystatechange = function () {
            if(req.readyState == 4) {
                if(req.status == 200 || req.status == 204) {
                    _onSuccess(req.responseText);
                }
                else {
                    _onError();
                }
            }
        };
        req.open(_method, _url, true);
        for(var i = 0; i < _headerKeys.length; i++) {
            var key = _headerKeys[i];
            var value = _headerValues[i];
            req.setRequestHeader(key, value);
        }
        if(_body) {
            req.send(_body);
        } else {
            req.send();
        }
    };
  });
  list_1_Object__ConsObject_ = (function (Item1, Item2)
  {
    this.Tag = 1.000000;
    this._CaseName = "Cons";
    this.Item1 = Item1;
    this.Item2 = Item2;
  });
  list_1_Object__ConsObject_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item1.CompareTo(that.Item1);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.Item2.CompareTo(that.Item2);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  list_1_Object__NilObject_ = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "Nil";
  });
  list_1_Object__NilObject_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  list_1_String__ConsString = (function (Item1, Item2)
  {
    this.Tag = 1.000000;
    this._CaseName = "Cons";
    this.Item1 = Item1;
    this.Item2 = Item2;
  });
  list_1_String__ConsString.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = ((this.Item1 < that.Item1) ? -1.000000 : ((this.Item1 == that.Item1) ? 0.000000 : 1.000000));
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.Item2.CompareTo(that.Item2);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  list_1_String__NilString = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "Nil";
  });
  list_1_String__NilString.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  list_1_Tuple_2_String__String__ConsTuple_2_String__String_ = (function (Item1, Item2)
  {
    this.Tag = 1.000000;
    this._CaseName = "Cons";
    this.Item1 = Item1;
    this.Item2 = Item2;
  });
  list_1_Tuple_2_String__String__ConsTuple_2_String__String_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      var __diff = 0.000000;
      __diff = this.Item1.CompareTo(that.Item1);
      diff = __diff;
      if ((diff != 0.000000)) 
      {
        return diff;
      }
      else
      {
        var ___diff = 0.000000;
        ___diff = this.Item2.CompareTo(that.Item2);
        diff = ___diff;
        if ((diff != 0.000000)) 
        {
          return diff;
        }
        else
        {
          return 0.000000;
        };
      };
    };
  });
  list_1_Tuple_2_String__String__NilTuple_2_String__String_ = (function ()
  {
    this.Tag = 0.000000;
    this._CaseName = "Nil";
  });
  list_1_Tuple_2_String__String__NilTuple_2_String__String_.prototype.CompareTo = (function (that)
  {
    var diff = 0.000000;
    var _diff = 0.000000;
    _diff = ((this.Tag < that.Tag) ? -1.000000 : ((this.Tag == that.Tag) ? 0.000000 : 1.000000));
    diff = _diff;
    if ((diff != 0.000000)) 
    {
      return diff;
    }
    else
    {
      return 0.000000;
    };
  });
  t_Boolean_ = (new Type___ctor$("Boolean", "System.Boolean", [], (new TypeKind__ClassType())));
  t_Decimal_ = (new Type___ctor$("Decimal", "System.Decimal", [], (new TypeKind__ClassType())));
  t_Double_ = (new Type___ctor$("Double", "System.Double", [], (new TypeKind__ClassType())));
  t_FSharpOption_1_Tuple_2___ = (new Type___ctor$("FSharpOption`1", "Microsoft.FSharp.Core.FSharpOption`1[[System.Tuple`2[[System.String, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[ChatExample.Shared+Message, ChatExample.Shared, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]][], mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]", [(new Type___ctor$("Tuple`2[]", "System.Tuple`2[[System.String, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[ChatExample.Shared+Message, ChatExample.Shared, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]][]", [], (new TypeKind__ArrayType(t_Tuple_2_String__Message_))))], (new TypeKind__UnionType([(new UnionCaseInfo___ctor$("None", 0, (function (args)
  {
    return {Tag: 0.000000};
  }), [])), (new UnionCaseInfo___ctor$("Some", 1, (function (args)
  {
    return {Tag: 1.000000, Value: args[0]};
  }), [(new PropertyInfo___ctor$("Value", (function (obj)
  {
    return Option__GetValue$Tuple_2___Tuple_2___(obj);
  }), (function (unitVar0)
  {
    return t_Tuple_2___;
  })))]))]))));
  t_Int32_ = (new Type___ctor$("Int32", "System.Int32", [], (new TypeKind__ClassType())));
  t_Int64_ = (new Type___ctor$("Int64", "System.Int64", [], (new TypeKind__ClassType())));
  t_Message_ = (new Type___ctor$("Message", "ChatExample.Shared+Message", [], (new TypeKind__RecordType((function (args)
  {
    return (new Message___ctor$(args[0], args[1], args[2]));
  }), [(new PropertyInfo___ctor$("Sender", (function (obj)
  {
    return obj.Sender;
  }), (function (unitVar0)
  {
    return t_String_;
  }))), (new PropertyInfo___ctor$("Subject", (function (obj)
  {
    return obj.Subject;
  }), (function (unitVar0)
  {
    return t_String_;
  }))), (new PropertyInfo___ctor$("Content", (function (obj)
  {
    return obj.Content;
  }), (function (unitVar0)
  {
    return t_String_;
  })))]))));
  t_PrimitiveType_ = (new Type___ctor$("PrimitiveType", "TypeInferred.HashBang.Runtime+PrimitiveType", [], (new TypeKind__UnionType([(new UnionCaseInfo___ctor$("BoolType", 0, (function (args)
  {
    return (new PrimitiveType__BoolType());
  }), [])), (new UnionCaseInfo___ctor$("IntType", 1, (function (args)
  {
    return (new PrimitiveType__IntType());
  }), [])), (new UnionCaseInfo___ctor$("StringType", 2, (function (args)
  {
    return (new PrimitiveType__StringType());
  }), [])), (new UnionCaseInfo___ctor$("UIntType", 3, (function (args)
  {
    return (new PrimitiveType__UIntType());
  }), [])), (new UnionCaseInfo___ctor$("HexType", 4, (function (args)
  {
    return (new PrimitiveType__HexType());
  }), [])), (new UnionCaseInfo___ctor$("FloatType", 5, (function (args)
  {
    return (new PrimitiveType__FloatType());
  }), [])), (new UnionCaseInfo___ctor$("DecimalType", 6, (function (args)
  {
    return (new PrimitiveType__DecimalType());
  }), [])), (new UnionCaseInfo___ctor$("CharType", 7, (function (args)
  {
    return (new PrimitiveType__CharType());
  }), []))]))));
  t_String_ = (new Type___ctor$("String", "System.String", [], (new TypeKind__ClassType())));
  t_Tuple_2_String__Message_ = (new Type___ctor$("Tuple`2", "System.Tuple`2[[System.String, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[ChatExample.Shared+Message, ChatExample.Shared, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]", [(new Type___ctor$("String", "System.String", [], (new TypeKind__ClassType()))), (new Type___ctor$("Message", "ChatExample.Shared+Message", [], (new TypeKind__RecordType((function (args)
  {
    return (new Message___ctor$(args[0], args[1], args[2]));
  }), [(new PropertyInfo___ctor$("Sender", (function (obj)
  {
    return obj.Sender;
  }), (function (unitVar0)
  {
    return t_String_;
  }))), (new PropertyInfo___ctor$("Subject", (function (obj)
  {
    return obj.Subject;
  }), (function (unitVar0)
  {
    return t_String_;
  }))), (new PropertyInfo___ctor$("Content", (function (obj)
  {
    return obj.Content;
  }), (function (unitVar0)
  {
    return t_String_;
  })))]))))], (new TypeKind__TupleType((function (args)
  {
    return (new TupleString_Message_(args[0], args[1]));
  }), [t_String_, t_Message_]))));
  t_Tuple_2___ = (new Type___ctor$("Tuple`2[]", "System.Tuple`2[[System.String, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[ChatExample.Shared+Message, ChatExample.Shared, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]][]", [], (new TypeKind__ArrayType(t_Tuple_2_String__Message_))));
  t_UInt32_ = (new Type___ctor$("UInt32", "System.UInt32", [], (new TypeKind__ClassType())));
  t_UInt64_ = (new Type___ctor$("UInt64", "System.UInt64", [], (new TypeKind__ClassType())));
  t_UrlPart_ = (new Type___ctor$("UrlPart", "TypeInferred.HashBang.Runtime+UrlPart", [], (new TypeKind__UnionType([(new UnionCaseInfo___ctor$("FixedPart", 0, (function (args)
  {
    return (new UrlPart__FixedPart(args[0]));
  }), [(new PropertyInfo___ctor$("Item", (function (obj)
  {
    return obj.Item;
  }), (function (unitVar0)
  {
    return t_String_;
  })))])), (new UnionCaseInfo___ctor$("VariablePart", 1, (function (args)
  {
    return (new UrlPart__VariablePart(args[0], args[1]));
  }), [(new PropertyInfo___ctor$("Item1", (function (obj)
  {
    return obj.Item1;
  }), (function (unitVar0)
  {
    return t_String_;
  }))), (new PropertyInfo___ctor$("Item2", (function (obj)
  {
    return obj.Item2;
  }), (function (unitVar0)
  {
    return t_PrimitiveType_;
  })))]))]))));
  t_UrlPart___ = (new Type___ctor$("UrlPart[]", "TypeInferred.HashBang.Runtime+UrlPart[]", [], (new TypeKind__ArrayType(t_UrlPart_))));
  Program__ctx = Program__get_ctx$();
  Serialization__deserializers = Serialization__get_deserializers$();
  SerializationExtensions__accessFlags = SerializationExtensions__get_accessFlags$();
  Dictionaries__nextId = Dictionaries__get_nextId$();
  SetTreeModule__tolerance = SetTreeModule__get_tolerance$();
  Program__main$()