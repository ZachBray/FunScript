﻿[<ReflectedDefinition>]
module ChatExample.Shared

type Message = {
    Sender : string
    Subject : string
    Content : string
}